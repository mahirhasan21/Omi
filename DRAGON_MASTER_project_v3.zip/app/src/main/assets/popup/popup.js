const EXT = globalThis.browser ?? globalThis.chrome;
const HAS_PROMISE_API = typeof globalThis.browser !== 'undefined' && EXT === globalThis.browser;
const DEFAULTS = {
  enabled: true,
  gainDb: 84,
  loudness: 20.0,
  maxBoost: 5000,
  drive: 1.8,
  thresholdDb: -60,
  ratio: 20,
  limiterDb: -0.1,
  presenceDb: 20,
  lowShelfDb: 14,
  highShelfDb: 16,
  sustain: true,
  sustainTargetDb: -2,
  sustainMaxGain: 64,
  forceRawMic: true,
  punch: 6,
  listenGain: 6,
  listenClarity: 6,
  listenBass: 4,
  listenPunch: 5,
  micBoost: 4
};
const PRESETS = {
  royal: {
    enabled: true,
    gainDb: 24,
    loudness: 4,
    maxBoost: 2000,
    drive: 0.28,
    thresholdDb: -38,
    ratio: 12,
    limiterDb: -2,
    presenceDb: 8,
    lowShelfDb: 4,
    highShelfDb: 6,
    sustain: true,
    sustainTargetDb: -8,
    sustainMaxGain: 12,
    forceRawMic: true,
    punch: 1
  },
  lord: {
    enabled: true,
    gainDb: 84,
    loudness: 20,
    maxBoost: 5000,
    drive: 3.2,
    thresholdDb: -60,
    ratio: 20,
    limiterDb: -0.1,
    presenceDb: 28,
    lowShelfDb: 14,
    highShelfDb: 16,
    sustain: true,
    sustainTargetDb: -2,
    sustainMaxGain: 64,
    forceRawMic: true,
    punch: 18
  }
};
PRESETS.mic = {
  enabled: true, gainDb: 48, loudness: 8, maxBoost: 3000, drive: 0.8,
  thresholdDb: -50, ratio: 16, limiterDb: -1, presenceDb: 14, lowShelfDb: 8,
  highShelfDb: 10, sustain: true, sustainTargetDb: -5, sustainMaxGain: 32, forceRawMic: true
};
PRESETS.mod = {
  enabled: true, gainDb: 62, loudness: 12, maxBoost: 4000, drive: 1.2,
  thresholdDb: -55, ratio: 18, limiterDb: -0.5, presenceDb: 18, lowShelfDb: 6,
  highShelfDb: 12, sustain: true, sustainTargetDb: -3, sustainMaxGain: 48, forceRawMic: true
};
PRESETS.ultra = {
  enabled: true, gainDb: 120, loudness: 200, maxBoost: 5000, drive: 5,
  thresholdDb: -75, ratio: 20, limiterDb: -0.1, presenceDb: 20, lowShelfDb: 12,
  highShelfDb: 16, sustain: true, sustainTargetDb: -1, sustainMaxGain: 64, forceRawMic: true, punch: 24
};
const PRESET_BTN = { royal: 'royalPreset', lord: 'lordPreset', mic: 'micPreset', mod: 'modPreset', ultra: 'ultraPreset' };
const ids = Object.keys(DEFAULTS);

function storageGet(key) {
  if (HAS_PROMISE_API) return EXT.storage.local.get(key);
  return new Promise((resolve) => {
    try {
      EXT.storage.local.get(key, (res) => {
        if (EXT.runtime?.lastError) resolve({});
        else resolve(res || {});
      });
    } catch (_) {
      resolve({});
    }
  });
}

function storageSet(value) {
  if (HAS_PROMISE_API) return EXT.storage.local.set(value);
  return new Promise((resolve) => {
    try {
      EXT.storage.local.set(value, () => resolve(!EXT.runtime?.lastError));
    } catch (_) {
      resolve(false);
    }
  });
}

function sendMessage(message) {
  if (HAS_PROMISE_API) return EXT.runtime.sendMessage(message);
  return new Promise((resolve) => {
    try {
      EXT.runtime.sendMessage(message, (res) => {
        if (EXT.runtime?.lastError) resolve(null);
        else resolve(res || null);
      });
    } catch (_) {
      resolve(null);
    }
  });
}

function numberText(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return String(value);
  return Math.abs(n) < 10 && !Number.isInteger(n) ? n.toFixed(1) : String(n);
}

function paintRanges() {
  document.querySelectorAll('input[type=range]').forEach((r) => {
    const min = Number(r.min || 0);
    const max = Number(r.max || 100);
    const pct = max > min ? ((Number(r.value) - min) / (max - min)) * 100 : 0;
    r.style.setProperty('--fill', pct + '%');
  });
}

function updateLabels() {
  paintRanges();
  ids.forEach((id) => {
    const el = document.getElementById(id);
    const label = document.getElementById(`${id}Val`);
    if (label && el?.type !== 'checkbox') label.textContent = numberText(el.value);
  });
}

function presetMatches(config, preset) {
  return Object.entries(preset).every(([key, value]) => Number(config[key]) === Number(value) || config[key] === value);
}

function activePreset(config) {
  for (const key of Object.keys(PRESET_BTN)) if (presetMatches(config, PRESETS[key])) return key;
  return 'custom';
}

function updatePresetState(config) {
  const active = activePreset(config);
  document.body.dataset.mode = active;
  Object.entries(PRESET_BTN).forEach(([key, id]) => {
    const btn = document.getElementById(id);
    btn?.classList.toggle('active', active === key);
    btn?.setAttribute('aria-pressed', String(active === key));
  });
}

function updateDial(config) {
  const v = Math.max(1, Number(config.listenGain) || 1);
  const dial = document.getElementById('dial');
  if (dial) dial.style.setProperty('--p', String(Math.round((Math.log(v) / Math.log(1000)) * 100)));
  document.querySelectorAll('[data-gear]').forEach((b) => b.classList.toggle('active', Number(b.dataset.gear) === v));
}

function applyToControls(config) {
  ids.forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (el.type === 'checkbox') el.checked = Boolean(config[id]);
    else el.value = config[id];
  });
  updateLabels();
  updatePresetState(config);
  updateDial(config);
  document.body.classList.toggle('on', Boolean(config.enabled));
}

async function readConfig() {
  const stored = await storageGet('micMaximizerConfig');
  const saved = stored.micMaximizerConfig || {};
  if (saved.forceRawMic === undefined) return { ...DEFAULTS };
  return { ...DEFAULTS, ...saved };
}

async function saveConfig(config) {
  const merged = { ...DEFAULTS, ...config };
  await storageSet({ micMaximizerConfig: merged });
  applyToControls(merged);
}

async function onControlInput(id, el) {
  const merged = await readConfig();
  merged[id] = el.type === 'checkbox' ? el.checked : Number(el.value);
  await saveConfig(merged);
}

async function initTheme() {
  let saved = (await storageGet('dmTheme')).dmTheme || 'ocean';
  if (!['ocean', 'sunset', 'rgb', 'ice', 'lime', 'ruby', 'gold'].includes(saved)) saved = 'ocean';
  const apply = (t) => {
    document.documentElement.dataset.theme = t;
    document.querySelectorAll('[data-set-theme]').forEach((b) => b.classList.toggle('on', b.dataset.setTheme === t));
  };
  apply(saved);
  document.querySelectorAll('[data-set-theme]').forEach((b) => b.addEventListener('click', () => {
    apply(b.dataset.setTheme);
    storageSet({ dmTheme: b.dataset.setTheme });
  }));
}

async function init() {
  if (!EXT?.storage?.local) return;
  initTheme();
  applyToControls(await readConfig());
  ids.forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input', () => onControlInput(id, el));
  });
  Object.entries(PRESET_BTN).forEach(([key, id]) => {
    document.getElementById(id)?.addEventListener('click', async () => {
      const current = await readConfig();
      await saveConfig({ ...current, ...PRESETS[key] });
    });
  });
  document.querySelectorAll('[data-gear]').forEach((b) => b.addEventListener('click', async () => {
    const current = await readConfig();
    await saveConfig({ ...current, listenGain: Number(b.dataset.gear) });
  }));
  document.getElementById('gearBtn')?.addEventListener('click', () => {
    const adv = document.getElementById('advanced');
    if (adv) {
      adv.hidden = !adv.hidden;
      if (!adv.hidden) adv.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
  document.getElementById('menuBtn')?.addEventListener('click', () => {
    document.getElementById('extras')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  document.getElementById('themeBtn')?.addEventListener('click', () => {
    const dots = [...document.querySelectorAll('[data-set-theme]')];
    const i = dots.findIndex((d) => d.classList.contains('on'));
    dots[(i + 1) % dots.length]?.click();
  });
}

async function refreshHookStatus() {
  const el = document.getElementById('hookStatus');
  if (!el || !EXT?.runtime) return;
  try {
    const status = await sendMessage({ type: 'MICMAX_STATUS_REQUEST' });
    const ageMs = status?.lastHeartbeat ? Date.now() - status.lastHeartbeat : Infinity;
    if (status?.ok && ageMs < 12000) {
      el.textContent = 'Active on this site ✔';
      el.className = 'status ok';
    } else {
      el.textContent = 'Waiting: Messenger / WhatsApp / Telegram / Instagram ট্যাব রিলোড দাও';
      el.className = 'status warn';
    }
  } catch (_) {
    el.textContent = 'Status unavailable';
    el.className = 'status warn';
  }
}

init();
setInterval(refreshHookStatus, 3000);
refreshHookStatus();

package com.mahir.dragonmaster;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;

/** Handles the Mute / Preset / End buttons of the call notification. */
public class CallActionReceiver extends BroadcastReceiver {

    static final String A_MUTE = "com.mahir.dragonmaster.MUTE";
    static final String A_PRESET = "com.mahir.dragonmaster.PRESET";
    static final String A_END = "com.mahir.dragonmaster.END";

    @Override
    public void onReceive(final Context c, Intent i) {
        String a = i == null ? null : i.getAction();
        if (a == null) return;
        final MainActivity m = MainActivity.sInst;
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);

        if (A_MUTE.equals(a)) {
            if (m != null) {
                m.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        m.toggleMic();
                    }
                });
            } else {
                MainActivity.sMicMuted = !MainActivity.sMicMuted;
                try {
                    am.setMicrophoneMute(MainActivity.sMicMuted);
                } catch (Exception ignored) {
                }
                restartService(c);
            }
        } else if (A_PRESET.equals(a)) {
            if (m != null) {
                m.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        m.nextPreset();
                    }
                });
            }
        } else if (A_END.equals(a)) {
            if (m != null) {
                m.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        m.endCall();
                    }
                });
            } else {
                MainActivity.sCallActive = false;
                MainActivity.sMicMuted = false;
                try {
                    am.setMicrophoneMute(false);
                } catch (Exception ignored) {
                }
                c.stopService(new Intent(c, CallService.class));
            }
        }
    }

    private void restartService(Context c) {
        try {
            Intent si = new Intent(c, CallService.class);
            if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(si);
            else c.startService(si);
        } catch (Exception ignored) {
        }
    }
}

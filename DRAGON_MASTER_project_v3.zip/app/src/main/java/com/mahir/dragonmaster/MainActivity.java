package com.mahir.dragonmaster;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import android.app.PictureInPictureParams;
import android.content.res.Configuration;
import android.graphics.Outline;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.CancellationSignal;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Rational;
import android.view.ViewOutlineProvider;
import android.webkit.MimeTypeMap;
import android.widget.CheckBox;
import android.widget.SeekBar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {

    // ------------------------------------------------------------------ constants

    private static final int REQ_FILE = 101;
    private static final int REQ_MEDIA = 102;
    private static final int REQ_PERM = 103;
    private static final int REQ_BT = 105;
    private static final int REQ_EXPORT = 106;
    private static final int REQ_IMPORT = 107;
    private static final long MAX_MEDIA_BYTES = 40L * 1024L * 1024L;
    private static final int CHUNK = 3 * 128 * 1024;

    private static final String APP_TITLE = "DRAGON MASTER";
    private static final String APP_SUB = "মাহির ব্রাউজার কল";

    private static final String[] SITE_NAMES = {
            "Facebook", "Messenger", "Instagram", "WhatsApp Web", "Telegram Web",
            "Google Meet (beta)", "Discord (beta)"
    };
    private static final String[] SITE_URLS = {
            "https://www.facebook.com/",
            "https://www.messenger.com/",
            "https://www.instagram.com/",
            "https://web.whatsapp.com/",
            "https://web.telegram.org/k/",
            "https://meet.google.com/",
            "https://discord.com/app"
    };
    private static final String[] ALLOWED_HOSTS = {
            "facebook.com", "messenger.com", "instagram.com", "whatsapp.com",
            "telegram.org", "meet.google.com", "discord.com"
    };

    // name, bg, bar, card, accent, text, dim
    private static final String[][] THEMES = {
            {"Dragon Green", "#04121a", "#08202c", "#0e2f3f", "#5ff5d6", "#FFFFFF", "#8aa7b3"},
            {"Fire Red", "#140808", "#241010", "#361818", "#ff5a4d", "#FFFFFF", "#b99a97"},
            {"Ocean Blue", "#06101f", "#0b1c33", "#12294a", "#4da3ff", "#FFFFFF", "#8fa3bf"},
            {"Light", "#f2f5f7", "#ffffff", "#e3eaee", "#0a8f72", "#10222b", "#5d727c"},
            {"Purple Neon", "#0d0618", "#170a2b", "#241043", "#c77dff", "#FFFFFF", "#a99bc2"},
            {"Gold Black", "#0a0a0a", "#141414", "#201d14", "#ffc83d", "#FFFFFF", "#a8a08a"},
            {"Custom", "#04121a", "#08202c", "#0e2f3f", "#ff3d71", "#FFFFFF", "#8aa7b3"}
    };
    private static final int CUSTOM_THEME = 6;
    private static final String[] PRESET_ICONS = {"🔈", "🔊", "📢", "🗣"};
    private static final String[] SITE_ICONS = {"📘", "💬", "📸", "🟢", "✈", "🎥", "🎮"};
    private static final String[] PRESET_NAMES = {"Normal", "Loud", "Max", "Voice Clear"};
    private static final int[] PRESET_GAINS = {1, 6, 12, 3};

    private static final String ERROR_HTML = "<html><body style='background:#04121a;color:#fff;"
            + "font-family:sans-serif;text-align:center;padding:48px 20px'>"
            + "<h2 style='color:#5ff5d6'>DRAGON MASTER</h2>"
            + "<p>পেজ লোড হয়নি। ইন্টারনেট চেক করুন।</p><p>Page failed to load. Check internet.</p>"
            + "<p>⋮ → 🔄 Reload</p></body></html>";

    // call state survives recreate()
    static boolean sCallActive = false;
    static long sCallStart = 0;
    static boolean sMicMuted = false;
    private static long sLastStop = 0;
    static MainActivity sInst = null;

    // ------------------------------------------------------------------ fields

    private SharedPreferences prefs;
    private File mixDir;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private int themeIdx;
    private boolean bn;
    private int cBg, cBar, cCard, cAccent, cText, cDim;

    private FrameLayout root;
    private FrameLayout content;
    private ProgressBar progress;
    private TextView tvChip;
    private TextView[] navItems = new TextView[5];
    private int page = 0; // 0 home, 1 mic, 2 mixer, 3 web, 4 settings

    private LinearLayout topBar, navBar, webTabRow, webAddrBar;
    private FrameLayout drawerLayer;
    private View drawerScrim, drawerPanel;
    private int drawerW;
    private TextView drawerTimer;
    private TextView lockBio;
    private boolean inPip = false;
    private String lastSiteHost = "";
    private volatile String blobToken = "";
    private volatile boolean blobFirst = true;
    private File blobTmp;
    private FileOutputStream blobOut;
    private long blobTotal = 0;

    private ScrollView homeView;
    private WebView micPanel;
    private WebView mixerPanel;
    private LinearLayout webArea;
    private ScrollView settingsView;
    private LinearLayout settingsBox;

    private TextView tvMic, tvBat, tvNet, tvCall;

    // browser
    private static class Tab {
        WebView web;
        String title = "New";
    }

    private final List<Tab> tabs = new ArrayList<Tab>();
    private int curTab = -1;
    private WebView web;
    private FrameLayout webFrame;
    private LinearLayout tabStrip;
    private HorizontalScrollView tabScroll;
    private EditText urlBox;
    private String defaultUa;
    private boolean desktop;

    // floating call controls
    private LinearLayout fcall;
    private TextView fcTimer, fcMic;
    private int presetIdx = 0;

    // lock
    private FrameLayout lockView;
    private TextView lockDots, lockMsg;
    private final StringBuilder pinBuf = new StringBuilder();
    private int wrongCount = 0;
    private long lockUntil = 0;

    // fullscreen video
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    private String mixerState = "{\"items\":[],\"mics\":[],\"devices\":[]}";
    private long lastReady = 0;
    private String injectJs = null;

    private PermissionRequest pendingRequest;
    private ValueCallback<Uri[]> pendingFile;

    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private final AudioManager.OnAudioFocusChangeListener focusListener =
            new AudioManager.OnAudioFocusChangeListener() {
                @Override
                public void onAudioFocusChange(int change) {
                    resumeCallAudio();
                }
            };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sInst = this;
        prefs = getSharedPreferences("PREFS", MODE_PRIVATE);
        pruneCallLog();
        mixDir = new File(getFilesDir(), "mixer");
        mixDir.mkdirs();
        desktop = prefs.getBoolean("desktop", false);
        bn = prefs.getBoolean("bn", true);
        themeIdx = prefs.getInt("theme", 0);
        if (themeIdx < 0 || themeIdx >= THEMES.length) themeIdx = 0;
        String[] th = THEMES[themeIdx].clone();
        if (themeIdx == CUSTOM_THEME) {
            try {
                String ah = prefs.getString("accentHex", "#ff3d71");
                Color.parseColor(ah);
                th[4] = ah;
            } catch (Exception ignored) {
            }
        }
        cBg = Color.parseColor(th[1]);
        cBar = Color.parseColor(th[2]);
        cCard = Color.parseColor(th[3]);
        cAccent = Color.parseColor(th[4]);
        cText = Color.parseColor(th[5]);
        cDim = Color.parseColor(th[6]);

        getWindow().setStatusBarColor(cBar);
        getWindow().setNavigationBarColor(cBar);
        if (themeIdx == 3) {
            View d = getWindow().getDecorView();
            d.setSystemUiVisibility(d.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        applyWindowFlags();

        buildUi();

        ArrayList<String> want = new ArrayList<String>();
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) want.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33
                && !hasPerm(Manifest.permission.POST_NOTIFICATIONS)) {
            want.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (Build.VERSION.SDK_INT < 29 && !hasPerm(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            want.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!want.isEmpty()) requestPermissions(want.toArray(new String[0]), REQ_PERM + 1);

        restoreTabs();
        showPage(0);

        if (prefs.getString("pinHash", null) != null) showLock();
        showSplash();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        resumeCallAudio();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(tick);
        stopMicTest();
        saveTabs();
        super.onPause();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (prefs.getString("pinHash", null) != null && sLastStop > 0
                && System.currentTimeMillis() - sLastStop > prefs.getInt("lockDelay", 30000)) {
            showLock();
        }
    }

    @Override
    protected void onStop() {
        sLastStop = System.currentTimeMillis();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        stopMicTest();
        if (sInst == this) sInst = null;
        try {
            if (audioManager != null && !sCallActive) {
                if (Build.VERSION.SDK_INT >= 26 && focusRequest != null) {
                    audioManager.abandonAudioFocusRequest(focusRequest);
                } else {
                    audioManager.abandonAudioFocus(focusListener);
                }
            }
        } catch (Exception ignored) {
        }
        for (Tab t : tabs) t.web.destroy();
        if (micPanel != null) micPanel.destroy();
        if (mixerPanel != null) mixerPanel.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (drawerOpen()) {
            closeDrawer();
        } else if (customView != null) {
            hideCustom();
        } else if (lockView != null && lockView.getVisibility() == View.VISIBLE) {
            // locked: ignore
        } else if (page == 3 && web != null && web.canGoBack()) {
            web.goBack();
        } else if (page != 0) {
            showPage(0);
        } else {
            new AlertDialog.Builder(this)
                    .setTitle(APP_TITLE)
                    .setMessage(t("অ্যাপ থেকে বের হতে চান?", "Exit the app?"))
                    .setPositiveButton(t("হ্যাঁ", "Yes"), (d, w) -> finish())
                    .setNegativeButton(t("না", "No"), null)
                    .show();
        }
    }

    // ------------------------------------------------------------------ helpers

    private String t(String bnText, String enText) {
        return bn ? bnText : enText;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    private GradientDrawable round(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(radiusDp));
        g.setColor(fill);
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private TextView btn(String text, final View.OnClickListener l) {
        TextView tv = label(text, 14, cText, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(10), dp(12), dp(10), dp(12));
        GradientDrawable bg = round(cCard, alpha(cAccent, 0x66), 14);
        tv.setBackground(new RippleDrawable(
                ColorStateList.valueOf(alpha(cAccent, 0x55)), bg, null));
        tv.setClickable(true);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();
                        l.onClick(v);
                    }
                }).start();
            }
        });
        return tv;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.setBackground(round(cCard, alpha(cAccent, 0x40), 16));
        return c;
    }

    private LinearLayout.LayoutParams lpW(float w, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, w);
        p.setMargins(dp(margin), dp(margin), dp(margin), dp(margin));
        return p;
    }

    private LinearLayout.LayoutParams lpFull(int topMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(topMargin);
        return p;
    }

    private TextView section(String text) {
        TextView tv = label(text, 13, cAccent, true);
        tv.setPadding(dp(4), dp(16), 0, dp(6));
        return tv;
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void applyWindowFlags() {
        if (prefs.getBoolean("keepOn", true)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        if (prefs.getBoolean("secure", false)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                setRecentsScreenshotEnabled(!prefs.getBoolean("hidePreview", false));
            } catch (Exception ignored) {
            }
        }
    }

    private AudioManager am() {
        if (audioManager == null) audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        return audioManager;
    }

    // ------------------------------------------------------------------ main UI

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(cBg);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        // top bar
        LinearLayout bar = new LinearLayout(this);
        topBar = bar;
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(cBar);

        TextView menuBtn = label("☰", 24, cAccent, false);
        menuBtn.setGravity(Gravity.CENTER);
        menuBtn.setPadding(dp(16), 0, dp(14), 0);
        menuBtn.setOnClickListener(v -> openDrawer());
        bar.addView(menuBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ImageView logo = badgeView();
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(34), dp(34));
        logoLp.rightMargin = dp(10);
        bar.addView(logo, logoLp);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        TextView title = label(APP_TITLE, 17, cText, true);
        title.setSingleLine(true);
        titleCol.addView(title);
        TextView sub = label(APP_SUB, 12, cAccent, false);
        sub.setSingleLine(true);
        titleCol.addView(sub);
        bar.addView(titleCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        tvChip = label("⏱ 00:00", 12, cBar, true);
        tvChip.setPadding(dp(10), dp(4), dp(10), dp(4));
        tvChip.setBackground(round(cAccent, 0, 12));
        tvChip.setVisibility(View.GONE);
        LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chipLp.rightMargin = dp(6);
        bar.addView(tvChip, chipLp);

        TextView more = label("⋮", 26, cAccent, false);
        more.setGravity(Gravity.CENTER);
        more.setPadding(dp(14), 0, dp(16), 0);
        more.setOnClickListener(v -> showMore());
        bar.addView(more, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        col.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(cAccent));
        progress.setVisibility(View.GONE);
        col.addView(progress, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        // content pages
        content = new FrameLayout(this);
        homeView = (ScrollView) buildHome();
        micPanel = newPanelWebView();
        mixerPanel = newPanelWebView();
        buildWebArea();
        settingsView = new ScrollView(this);
        settingsView.setBackgroundColor(cBg);
        settingsBox = new LinearLayout(this);
        settingsBox.setOrientation(LinearLayout.VERTICAL);
        settingsBox.setPadding(dp(14), dp(10), dp(14), dp(24));
        settingsView.addView(settingsBox);

        FrameLayout.LayoutParams full = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        content.addView(homeView, full);
        content.addView(micPanel, full);
        content.addView(mixerPanel, full);
        content.addView(webArea, full);
        content.addView(settingsView, full);
        col.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        navBar = (LinearLayout) buildNav();
        col.addView(navBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(62)));

        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        buildFloatingCall();
        buildDrawer();
        buildLock();
        setContentView(root);
    }

    private View buildNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(cBar);
        String[] icons = {"🏠", "🎤", "🎵", "🌐", "⚙"};
        String[] names = {t("হোম", "Home"), t("মাইক", "Mic"), t("মিক্সার", "Mixer"),
                t("ওয়েব", "Web"), t("সেটিং", "Settings")};
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            TextView item = new TextView(this);
            item.setText(icons[i]);
            item.setTextSize(24);
            item.setContentDescription(names[i]);
            item.setGravity(Gravity.CENTER);
            item.setTextColor(cDim);
            item.setClickable(true);
            item.setBackground(new RippleDrawable(
                    ColorStateList.valueOf(alpha(cAccent, 0x40)), null, null));
            item.setOnClickListener(v -> showPage(idx));
            navItems[i] = item;
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
            nlp.setMargins(dp(4), dp(6), dp(4), dp(6));
            nav.addView(item, nlp);
        }
        return nav;
    }

    private void showPage(int p) {
        page = p;
        homeView.setVisibility(p == 0 ? View.VISIBLE : View.GONE);
        micPanel.setVisibility(p == 1 ? View.VISIBLE : View.GONE);
        mixerPanel.setVisibility(p == 2 ? View.VISIBLE : View.GONE);
        webArea.setVisibility(p == 3 ? View.VISIBLE : View.GONE);
        settingsView.setVisibility(p == 4 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 5; i++) {
            navItems[i].setAlpha(i == p ? 1f : 0.5f);
            navItems[i].setBackground(i == p ? round(alpha(cAccent, 0x33), 0, 16)
                    : new RippleDrawable(ColorStateList.valueOf(alpha(cAccent, 0x40)), null, null));
        }
        if (p == 1) micPanel.loadUrl("file:///android_asset/popup/popup.html");
        if (p == 2) mixerPanel.loadUrl("file:///android_asset/popup/mixer.html");
        if (p == 4) buildSettings();
        if (p != 3) progress.setVisibility(View.GONE);
        updateStatus();
    }

    // ------------------------------------------------------------------ splash

    private void showSplash() {
        final FrameLayout sp = new FrameLayout(this);
        sp.setBackgroundColor(cBg);
        sp.setClickable(true);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        ImageView iv = badgeView();
        l.addView(iv, new LinearLayout.LayoutParams(dp(150), dp(150)));
        TextView n = label(APP_TITLE, 26, cAccent, true);
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, dp(16), 0, dp(4));
        l.addView(n);
        TextView s = label(APP_SUB, 14, cDim, false);
        s.setGravity(Gravity.CENTER);
        l.addView(s);
        sp.addView(l, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(sp, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        sp.animate().alpha(0f).setStartDelay(1100).setDuration(400).withEndAction(new Runnable() {
            @Override
            public void run() {
                root.removeView(sp);
            }
        }).start();
    }

    // ------------------------------------------------------------------ home / dashboard

    private TextView statusCard(LinearLayout row, String emoji, String title) {
        LinearLayout c = card();
        c.addView(label(emoji, 20, cDim, false));
        TextView v = label("--", 17, cAccent, true);
        v.setPadding(0, dp(4), 0, 0);
        c.addView(v);
        row.addView(c, lpW(1f, 4));
        return v;
    }

    private View buildHome() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(cBg);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(14), dp(14), dp(24));

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(0, dp(4), 0, dp(4));
        hero.addView(badgeView(), new LinearLayout.LayoutParams(dp(150), dp(150)));
        TextView ht = label(APP_TITLE, 22, cAccent, true);
        ht.setPadding(0, dp(10), 0, 0);
        hero.addView(ht);
        hero.addView(label(APP_SUB, 13, cDim, false));
        c.addView(hero, lpFull(0));

        c.addView(section("📊"));
        LinearLayout r1 = new LinearLayout(this);
        tvMic = statusCard(r1, "🎤", t("মাইক", "Mic"));
        tvBat = statusCard(r1, "🔋", t("ব্যাটারি", "Battery"));
        c.addView(r1);
        LinearLayout r2 = new LinearLayout(this);
        tvNet = statusCard(r2, "📶", t("নেট", "Network"));
        tvCall = statusCard(r2, "⏱", t("কলের সময়", "Call time"));
        c.addView(r2);

        c.addView(section("🎛"));
        LinearLayout pr = new LinearLayout(this);
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            pr.addView(iconBtn(PRESET_ICONS[i], PRESET_NAMES[i] + " ×" + PRESET_GAINS[i],
                    v -> applyPreset(idx, true)), lpW(1f, 3));
        }
        c.addView(pr);

        c.addView(section("🌐"));
        LinearLayout row = null;
        for (int i = 0; i < SITE_NAMES.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                c.addView(row);
            }
            final String url = SITE_URLS[i];
            row.addView(btn(SITE_ICONS[i] + " " + SITE_NAMES[i], v -> openSite(url)), lpW(1f, 3));
            if (i == SITE_NAMES.length - 1 && i % 2 == 0) {
                row.addView(new View(this), lpW(1f, 3));
            }
        }
        sv.addView(c);
        return sv;
    }

    private void openSite(String url) {
        showPage(3);
        if (web != null) web.loadUrl(url);
    }

    private String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, sec);
        return String.format("%02d:%02d", m, sec);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateStatus();
            handler.postDelayed(this, 1000);
        }
    };

    private void updateStatus() {
        String ct = sCallActive ? fmt(System.currentTimeMillis() - sCallStart) : "--:--";
        if (tvChip != null) {
            tvChip.setText("⏱ " + ct);
            tvChip.setVisibility(sCallActive ? View.VISIBLE : View.GONE);
        }
        if (fcTimer != null) fcTimer.setText(ct);
        if (drawerTimer != null) drawerTimer.setText("⏱ " + ct);
        if (page != 0 || tvMic == null) return;
        String mic;
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) mic = "✗ " + t("অনুমতি নেই", "No permission");
        else if (sMicMuted) mic = "🔇 Muted";
        else if (sCallActive) mic = "● Live";
        else mic = "✓ Ready";
        tvMic.setText(mic);
        tvCall.setText(ct);
        try {
            Intent bi = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bi != null) {
                int lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                tvBat.setText(lvl < 0 ? "--" : (lvl * 100 / sc) + "%");
            }
        } catch (Exception ignored) {
        }
        String net = t("নেই", "Offline");
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            if (nc != null) {
                if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) net = "Wi-Fi";
                else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) net = "Mobile";
                else net = "Online";
            }
        } catch (Exception ignored) {
        }
        tvNet.setText(net);
    }

    // ------------------------------------------------------------------ presets

    // ------------------------------------------------------------------ floating call controls

    private TextView fcBtn(String text, View.OnClickListener l) {
        TextView tv = label(text, 20, cText, false);
        tv.setGravity(Gravity.CENTER);
        tv.setClickable(true);
        tv.setOnClickListener(l);
        return tv;
    }

    private void buildFloatingCall() {
        fcall = new LinearLayout(this);
        fcall.setOrientation(LinearLayout.VERTICAL);
        fcall.setGravity(Gravity.CENTER_HORIZONTAL);
        fcall.setPadding(dp(6), dp(8), dp(6), dp(8));
        fcall.setBackground(round(alpha(cCard, 0xEE), alpha(cAccent, 0x99), 20));
        fcall.setElevation(dp(10));
        fcall.setVisibility(View.GONE);

        fcTimer = label("00:00", 11, cAccent, true);
        fcTimer.setGravity(Gravity.CENTER);
        fcall.addView(fcTimer);

        fcMic = fcBtn("🎤", v -> toggleMic());
        fcall.addView(fcMic, new LinearLayout.LayoutParams(dp(46), dp(44)));
        fcall.addView(fcBtn("🔉", v -> adjustVol(false)), new LinearLayout.LayoutParams(dp(46), dp(44)));
        fcall.addView(fcBtn("🔊", v -> adjustVol(true)), new LinearLayout.LayoutParams(dp(46), dp(44)));
        fcall.addView(fcBtn("🎛", v -> {
            nextPreset();
        }), new LinearLayout.LayoutParams(dp(46), dp(44)));
        fcall.addView(fcBtn("⏹", v -> endCall()), new LinearLayout.LayoutParams(dp(46), dp(44)));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END | Gravity.CENTER_VERTICAL);
        lp.rightMargin = dp(6);
        root.addView(fcall, lp);
    }

    void toggleMic() {
        sMicMuted = !sMicMuted;
        try {
            am().setMicrophoneMute(sMicMuted);
        } catch (Exception ignored) {
        }
        updateCallUi();
        refreshNotif();
        toast(sMicMuted ? "🔇 Mic OFF" : "🎤 Mic ON");
    }

    private void adjustVol(boolean up) {
        try {
            int dir = up ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER;
            am().adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
            am().adjustStreamVolume(AudioManager.STREAM_VOICE_CALL, dir, 0);
        } catch (Exception ignored) {
        }
    }

    private void updateCallUi() {
        if (fcall != null) fcall.setVisibility(sCallActive ? View.VISIBLE : View.GONE);
        if (fcMic != null) fcMic.setText(sMicMuted ? "🔇" : "🎤");
        updateStatus();
    }

    private void callStarted() {
        if (sCallActive) return;
        sCallActive = true;
        sCallStart = System.currentTimeMillis();
        startCallAudio();
        applyRoute(prefs.getInt("route", 0), false);
        logCallStart();
        try {
            Intent si = new Intent(this, CallService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(si);
            else startService(si);
        } catch (Exception ignored) {
        }
        int auto = prefs.getInt("autoPreset", -1);
        if (auto >= 0 && auto < 4) applyPreset(auto, false);
        updateCallUi();
    }

    void endCall() {
        logCallEnd();
        sCallActive = false;
        sMicMuted = false;
        try {
            am().setMicrophoneMute(false);
        } catch (Exception ignored) {
        }
        try {
            stopService(new Intent(this, CallService.class));
        } catch (Exception ignored) {
        }
        updateCallUi();
    }

    // ------------------------------------------------------------------ browser area

    private void buildWebArea() {
        webArea = new LinearLayout(this);
        webArea.setOrientation(LinearLayout.VERTICAL);
        webArea.setBackgroundColor(cBg);

        // tab strip
        LinearLayout tabRow = new LinearLayout(this);
        webTabRow = tabRow;
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setGravity(Gravity.CENTER_VERTICAL);
        tabRow.setBackgroundColor(cBar);
        tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabStrip = new LinearLayout(this);
        tabStrip.setOrientation(LinearLayout.HORIZONTAL);
        tabScroll.addView(tabStrip);
        tabRow.addView(tabScroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView plus = label("＋", 22, cAccent, true);
        plus.setGravity(Gravity.CENTER);
        plus.setPadding(dp(14), dp(4), dp(14), dp(4));
        plus.setOnClickListener(v -> createTab("https://www.google.com/"));
        tabRow.addView(plus);
        webArea.addView(tabRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        // address bar
        LinearLayout ab = new LinearLayout(this);
        webAddrBar = ab;
        ab.setOrientation(LinearLayout.HORIZONTAL);
        ab.setGravity(Gravity.CENTER_VERTICAL);
        ab.setBackgroundColor(cBar);
        ab.setPadding(dp(6), dp(2), dp(6), dp(6));
        TextView back = label("◀", 18, cAccent, false);
        back.setPadding(dp(10), dp(6), dp(10), dp(6));
        back.setOnClickListener(v -> {
            if (web != null && web.canGoBack()) web.goBack();
        });
        TextView fwd = label("▶", 18, cAccent, false);
        fwd.setPadding(dp(10), dp(6), dp(10), dp(6));
        fwd.setOnClickListener(v -> {
            if (web != null && web.canGoForward()) web.goForward();
        });
        ab.addView(back);
        ab.addView(fwd);

        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setTextSize(13);
        urlBox.setTextColor(cText);
        urlBox.setHintTextColor(cDim);
        urlBox.setHint(t("সার্চ বা লিংক লিখুন", "Search or type link"));
        urlBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBox.setBackground(round(cCard, alpha(cAccent, 0x40), 18));
        urlBox.setPadding(dp(14), dp(6), dp(14), dp(6));
        urlBox.setOnEditorActionListener((v, actionId, ev) -> {
            goToUrlBox();
            return true;
        });
        ab.addView(urlBox, new LinearLayout.LayoutParams(0, dp(38), 1f));

        TextView star = label("⭐", 18, cAccent, false);
        star.setPadding(dp(10), dp(6), dp(6), dp(6));
        star.setOnClickListener(v -> addBookmarkCurrent());
        TextView rl = label("🔄", 18, cAccent, false);
        rl.setPadding(dp(6), dp(6), dp(8), dp(6));
        rl.setOnClickListener(v -> reloadPage());
        ab.addView(star);
        ab.addView(rl);
        webArea.addView(ab, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        webFrame = new FrameLayout(this);
        webArea.addView(webFrame, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void goToUrlBox() {
        String q = urlBox.getText().toString().trim();
        if (q.isEmpty() || web == null) return;
        String url;
        if (q.startsWith("http://") || q.startsWith("https://")) {
            url = q;
        } else if (q.contains(" ") || !q.contains(".")) {
            url = "https://www.google.com/search?q=" + Uri.encode(q);
        } else {
            url = "https://" + q;
        }
        web.loadUrl(url);
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
        urlBox.clearFocus();
    }

    private Tab createTab(String url) {
        if (tabs.size() >= 8) {
            toast(t("সর্বোচ্চ ৮টা ট্যাব", "Max 8 tabs"));
            return null;
        }
        WebView w = new WebView(this);
        setupWebView(w);
        Tab tb = new Tab();
        tb.web = w;
        tabs.add(tb);
        webFrame.addView(w, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        selectTab(tabs.size() - 1);
        w.loadUrl(url);
        return tb;
    }

    private void selectTab(int i) {
        curTab = i;
        for (int j = 0; j < tabs.size(); j++) {
            tabs.get(j).web.setVisibility(j == i ? View.VISIBLE : View.GONE);
        }
        web = tabs.get(i).web;
        progress.setVisibility(View.GONE);
        String u = web.getUrl();
        if (u != null && !urlBox.hasFocus()) urlBox.setText(u);
        applySitePreset(u);
        rebuildTabStrip();
    }

    private void closeTab(int i) {
        if (tabs.size() <= 1) {
            web.loadUrl(SITE_URLS[1]);
            return;
        }
        Tab tb = tabs.remove(i);
        webFrame.removeView(tb.web);
        tb.web.destroy();
        selectTab(Math.min(i, tabs.size() - 1));
    }

    private void rebuildTabStrip() {
        tabStrip.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            boolean on = i == curTab;
            chip.setBackground(round(on ? cCard : cBar, on ? cAccent : alpha(cDim, 0x55), 14));
            chip.setPadding(dp(10), dp(4), dp(4), dp(4));
            String ttl = tabs.get(i).title;
            if (ttl == null || ttl.isEmpty()) ttl = "New";
            if (ttl.length() > 14) ttl = ttl.substring(0, 14) + "…";
            TextView name = label(ttl, 12, on ? cAccent : cText, on);
            name.setOnClickListener(v -> selectTab(idx));
            chip.addView(name);
            TextView x = label("✕", 12, cDim, false);
            x.setPadding(dp(8), dp(2), dp(8), dp(2));
            x.setOnClickListener(v -> closeTab(idx));
            chip.addView(x);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(4), dp(5), dp(2), dp(5));
            tabStrip.addView(chip, lp);
        }
    }

    private void saveTabs() {
        try {
            JSONArray a = new JSONArray();
            for (Tab tb : tabs) {
                String u = tb.web.getUrl();
                if (u != null && u.startsWith("http")) a.put(u);
            }
            prefs.edit().putString("tabs", a.toString()).putInt("curTab", Math.max(curTab, 0)).apply();
        } catch (Exception ignored) {
        }
    }

    private void restoreTabs() {
        ArrayList<String> urls = new ArrayList<String>();
        try {
            JSONArray a = new JSONArray(prefs.getString("tabs", "[]"));
            for (int i = 0; i < a.length() && i < 8; i++) urls.add(a.getString(i));
        } catch (Exception ignored) {
        }
        if (urls.isEmpty()) urls.add(SITE_URLS[1]);
        for (String u : urls) createTab(u);
        int c = prefs.getInt("curTab", 0);
        if (c >= 0 && c < tabs.size()) selectTab(c);
    }

    private void reloadPage() {
        if (web == null) return;
        String u = web.getUrl();
        if (u == null || !u.startsWith("http")) {
            web.loadUrl(SITE_URLS[1]);
        } else {
            web.reload();
        }
    }

    // ------------------------------------------------------------------ WebViews

    private void applyUa(WebView w) {
        String ua = defaultUa == null ? "" : defaultUa;
        ua = ua.replace("; wv", "");
        if (desktop) {
            ua = ua.replaceAll("\\(Linux; Android[^)]*\\)", "(X11; Linux x86_64)").replace(" Mobile", "");
        }
        WebSettings s = w.getSettings();
        s.setUserAgentString(ua);
        s.setUseWideViewPort(desktop);
        s.setLoadWithOverviewMode(desktop);
    }

    private void setupWebView(final WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setTextZoom(prefs.getInt("zoom", 100));
        if (defaultUa == null) defaultUa = s.getUserAgentString();
        applyUa(w);

        w.setBackgroundColor(cBg);
        w.setTag(Boolean.FALSE);
        w.addJavascriptInterface(new MainBridge(), "SSBridge");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                return !(u.startsWith("http://") || u.startsWith("https://"));
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    view.loadDataWithBaseURL(null, ERROR_HTML, "text/html", "UTF-8", null);
                }
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap icon) {
                view.setTag(Boolean.FALSE);
                inject(view);
                if (view == web && url != null && url.startsWith("http") && !urlBox.hasFocus()) {
                    urlBox.setText(url);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && url.startsWith("http")) {
                    addHistory(view.getTitle(), url);
                    if (view == web && !urlBox.hasFocus()) urlBox.setText(url);
                    if (view == web) applySitePreset(url);
                }
                inject(view);
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                if (view == web && page == 3) {
                    progress.setProgress(p);
                    progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                }
                if (p >= 30 && !Boolean.TRUE.equals(view.getTag())) {
                    view.setTag(Boolean.TRUE);
                    inject(view);
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                for (Tab tb : tabs) {
                    if (tb.web == view) {
                        tb.title = title;
                        rebuildTabStrip();
                        break;
                    }
                }
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = v;
                customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handlePermission(request);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (pendingFile != null) pendingFile.onReceiveValue(null);
                pendingFile = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    pendingFile = null;
                    return false;
                }
                return true;
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                if (url.startsWith("blob:")) {
                    blobDownload(w, url, mime);
                    return;
                }
                if (url.startsWith("data:")) {
                    saveDataUrl(url);
                    return;
                }
                try {
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    r.setMimeType(mime);
                    String ck = CookieManager.getInstance().getCookie(url);
                    if (ck != null) r.addRequestHeader("cookie", ck);
                    r.addRequestHeader("User-Agent", ua);
                    r.setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    String fn = URLUtil.guessFileName(url, cd, mime);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
                    ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                    toast("Downloading: " + fn);
                } catch (Exception e) {
                    toast("Download failed");
                }
            }
        });
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        getWindow().getDecorView().setSystemUiVisibility(
                themeIdx == 3 ? View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : 0);
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
    }

    private WebView newPanelWebView() {
        WebView p = new WebView(this);
        WebSettings s = p.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        p.setBackgroundColor(Color.parseColor("#04121a"));
        p.addJavascriptInterface(new PanelBridge(), "SSPanel");
        p.setWebViewClient(new WebViewClient());
        p.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handlePermission(request);
                    }
                });
            }
        });
        return p;
    }

    private boolean hostAllowed(String url) {
        if (url == null) return false;
        String host;
        try {
            host = Uri.parse(url).getHost();
        } catch (Exception e) {
            return false;
        }
        if (host == null) return false;
        for (String h : ALLOWED_HOSTS) {
            if (host.equals(h) || host.endsWith("." + h)) return true;
        }
        return false;
    }

    private String readAsset(String name) {
        try {
            InputStream in = getAssets().open(name);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void inject(WebView view) {
        if (view == null || !hostAllowed(view.getUrl())) return;
        if (injectJs == null) {
            injectJs = readAsset("bridge.js") + "\n;" + readAsset("core/injector.js")
                    + "\n;" + readAsset("mixer.js") + "\n;";
        }
        view.evaluateJavascript(injectJs
                + "window.__ssMixer&&window.__ssMixer.cmd({t:'lib',items:" + libJson() + "});", null);
    }

    private void runInMain(final String js) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(js, null);
            }
        });
    }

    // ------------------------------------------------------------------ bookmarks / history

    private JSONArray loadList(String key) {
        try {
            return new JSONArray(prefs.getString(key, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void addHistory(String name, String url) {
        try {
            JSONArray a = loadList("history");
            if (a.length() > 0 && url.equals(a.getJSONObject(a.length() - 1).optString("u"))) return;
            JSONObject o = new JSONObject();
            o.put("n", name == null || name.isEmpty() ? url : name);
            o.put("u", url);
            a.put(o);
            JSONArray out = new JSONArray();
            int start = Math.max(0, a.length() - 50);
            for (int i = start; i < a.length(); i++) out.put(a.get(i));
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void addBookmarkCurrent() {
        if (web == null || web.getUrl() == null || !web.getUrl().startsWith("http")) return;
        try {
            JSONArray a = loadList("bookmarks");
            for (int i = 0; i < a.length(); i++) {
                if (web.getUrl().equals(a.getJSONObject(i).optString("u"))) {
                    toast(t("আগেই আছে", "Already saved"));
                    return;
                }
            }
            JSONObject o = new JSONObject();
            String n = web.getTitle();
            o.put("n", n == null || n.isEmpty() ? web.getUrl() : n);
            o.put("u", web.getUrl());
            a.put(o);
            prefs.edit().putString("bookmarks", a.toString()).apply();
            toast("⭐ " + t("বুকমার্ক হয়েছে", "Bookmarked"));
        } catch (Exception ignored) {
        }
    }

    private void showUrlList(final String key, String title, final boolean allowAdd) {
        final JSONArray a = loadList(key);
        final int n = a.length();
        if (n == 0) {
            toast(t("খালি", "Empty"));
            return;
        }
        final String[] names = new String[n];
        final String[] urls = new String[n];
        for (int i = 0; i < n; i++) {
            JSONObject o = a.optJSONObject(n - 1 - i);
            names[i] = o == null ? "" : o.optString("n");
            urls[i] = o == null ? "" : o.optString("u");
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(title)
                .setItems(names, (d, which) -> openSite(urls[which]));
        if (key.equals("history")) {
            b.setNegativeButton(t("মুছুন", "Clear"), (d, w) ->
                    prefs.edit().putString("history", "[]").apply());
        } else {
            b.setNegativeButton(t("মুছুন (সব)", "Clear all"), (d, w) ->
                    prefs.edit().putString("bookmarks", "[]").apply());
        }
        b.show();
    }

    // ------------------------------------------------------------------ menus

    private void showSites() {
        new AlertDialog.Builder(this)
                .setTitle(t("ওয়েব", "Web"))
                .setItems(SITE_NAMES, (d, which) -> {
                    prefs.edit().putString("lastUrl", SITE_URLS[which]).apply();
                    openSite(SITE_URLS[which]);
                })
                .show();
    }

    private void showMore() {
        final Dialog dlg = new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(14), dp(12), dp(14));
        box.setBackground(round(cBar, alpha(cAccent, 0x80), 22));

        final String[] icons = {"◀", "▶", "🔄", "💬", desktop ? "🖥✓" : "🖥", "🔊", "🔍", "📸", "🔗", "📤", "🌐", "🖼"};
        final String[] names = {"Back", "Forward", "Reload", "Messenger", "Desktop", "Volume Max",
                t("খুঁজুন", "Find"), t("স্ক্রিনশট", "Screenshot"), t("লিংক কপি", "Copy link"),
                t("শেয়ার", "Share"), t("ব্রাউজার", "Browser"), "PiP"};
        LinearLayout row = null;
        for (int i = 0; i < icons.length; i++) {
            if (i % 4 == 0) {
                row = new LinearLayout(this);
                box.addView(row);
            }
            final int idx = i;
            row.addView(iconBtn(icons[i], names[i], v -> {
                dlg.dismiss();
                menuAction(idx);
            }), lpW(1f, 4));
        }
        TextView hint = label(t("আইকন চেপে ধরলে নাম দেখাবে", "Long-press an icon for its name"),
                11, cDim, false);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(8), 0, 0);
        box.addView(hint, lpFull(0));
        sv.addView(box);
        dlg.setContentView(sv);
        dlg.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dlg.show();
        dlg.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.94f),
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void menuAction(int which) {
        String cur = web == null || web.getUrl() == null ? "" : web.getUrl();
        switch (which) {
            case 0:
                if (web != null && web.canGoBack()) web.goBack();
                break;
            case 1:
                if (web != null && web.canGoForward()) web.goForward();
                break;
            case 2:
                reloadPage();
                break;
            case 3:
                openSite(SITE_URLS[1]);
                break;
            case 4:
                toggleDesktop();
                break;
            case 5:
                try {
                    AudioManager a = am();
                    a.setStreamVolume(AudioManager.STREAM_MUSIC,
                            a.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
                    a.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                            a.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0);
                } catch (Exception ignored) {
                }
                toast("🔊 Volume Max ✓");
                break;
            case 6:
                findInPage();
                break;
            case 7:
                takeScreenshot();
                break;
            case 8:
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("link", cur));
                toast(t("লিংক কপি হয়েছে", "Link copied"));
                break;
            case 9:
                Intent sh = new Intent(Intent.ACTION_SEND);
                sh.setType("text/plain");
                sh.putExtra(Intent.EXTRA_TEXT, cur);
                startActivity(Intent.createChooser(sh, "Share"));
                break;
            case 10:
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(cur)));
                } catch (Exception e) {
                    toast("Cannot open");
                }
                break;
            case 11:
                enterPip();
                break;
            case 100:
                try {
                    startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
                } catch (Exception e) {
                    toast("Cannot open");
                }
                break;
            default:
                showPage(4);
                break;
        }
    }

    private void toggleDesktop() {
        desktop = !desktop;
        prefs.edit().putBoolean("desktop", desktop).apply();
        for (Tab tb : tabs) applyUa(tb.web);
        reloadPage();
        toast("Desktop mode: " + (desktop ? "ON" : "OFF"));
    }

    private void findInPage() {
        if (web == null) return;
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("🔍 " + t("পেজে খুঁজুন", "Find in page"))
                .setView(et)
                .setPositiveButton(t("খুঁজুন", "Find"), (d, w) -> {
                    String q = et.getText().toString();
                    if (!q.isEmpty()) web.findAllAsync(q);
                })
                .setNeutralButton(t("পরেরটা", "Next"), (d, w) -> web.findNext(true))
                .setNegativeButton(t("বন্ধ", "Clear"), (d, w) -> web.clearMatches())
                .show();
    }

    private void takeScreenshot() {
        if (web == null || web.getWidth() == 0) return;
        if (Build.VERSION.SDK_INT < 29) {
            toast(t("স্ক্রিনশট Android 10+ এ চলে", "Screenshot needs Android 10+"));
            return;
        }
        try {
            Bitmap bmp = Bitmap.createBitmap(web.getWidth(), web.getHeight(), Bitmap.Config.ARGB_8888);
            web.draw(new Canvas(bmp));
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "DragonMaster_" + System.currentTimeMillis() + ".png");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DragonMaster");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            OutputStream os = getContentResolver().openOutputStream(u);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();
            toast("📸 " + t("সেভ হয়েছে (Pictures/DragonMaster)", "Saved (Pictures/DragonMaster)"));
        } catch (Exception e) {
            toast("Screenshot failed");
        }
    }

    // ------------------------------------------------------------------ settings page

    private void settingRow(String title, String value, View.OnClickListener l) {
        LinearLayout r = card();
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setClickable(true);
        r.setOnClickListener(l);
        TextView tt = label(title, 15, cText, false);
        r.addView(tt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView vv = label(value, 13, cAccent, true);
        vv.setGravity(Gravity.END);
        r.addView(vv);
        settingsBox.addView(r, lpFull(8));
    }

    private String onOff(boolean b) {
        return b ? "ON ✓" : "OFF";
    }

    // ------------------------------------------------------------------ app lock

    private String hashPin(String pin) {
        try {
            String salt = prefs.getString("pinSalt", "");
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest((salt + pin).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : h) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void pinMenu() {
        final boolean hasPin = prefs.getString("pinHash", null) != null;
        String[] items = hasPin
                ? new String[]{t("PIN বদলান", "Change PIN"), t("লক বন্ধ করুন", "Remove lock")}
                : new String[]{t("PIN সেট করুন", "Set PIN")};
        new AlertDialog.Builder(this).setTitle("🔐 App lock")
                .setItems(items, (d, w) -> {
                    if (hasPin && w == 1) {
                        prefs.edit().remove("pinHash").remove("pinSalt").remove("pinLen").remove("bio").apply();
                        buildSettings();
                    } else {
                        setPinDialog();
                    }
                }).show();
    }

    private void setPinDialog() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        et.setHint("4-6 digits");
        new AlertDialog.Builder(this).setTitle(t("নতুন PIN (৪-৬ সংখ্যা)", "New PIN (4-6 digits)"))
                .setView(et)
                .setPositiveButton("OK", (d, w) -> {
                    String p = et.getText().toString().trim();
                    if (p.length() < 4 || p.length() > 6) {
                        toast(t("৪ থেকে ৬ সংখ্যা দিন", "Use 4 to 6 digits"));
                        return;
                    }
                    String salt = Long.toString(new Random().nextLong(), 36);
                    prefs.edit().putString("pinSalt", salt).apply();
                    prefs.edit().putString("pinHash", hashPin(p)).putInt("pinLen", p.length()).apply();
                    toast("🔐 ✓");
                    buildSettings();
                })
                .setNegativeButton("Cancel", null).show();
    }

    private void buildLock() {
        lockView = new FrameLayout(this);
        lockView.setBackgroundColor(cBg);
        lockView.setClickable(true);
        lockView.setVisibility(View.GONE);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        ImageView iv = badgeView();
        l.addView(iv, new LinearLayout.LayoutParams(dp(110), dp(110)));
        TextView n = label(APP_TITLE, 20, cAccent, true);
        n.setPadding(0, dp(10), 0, dp(2));
        l.addView(n);
        lockMsg = label(t("PIN দিন", "Enter PIN"), 14, cDim, false);
        l.addView(lockMsg);
        lockDots = label("", 28, cAccent, true);
        lockDots.setPadding(0, dp(12), 0, dp(16));
        l.addView(lockDots);

        String[][] keys = {{"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"}, {"", "0", "⌫"}};
        for (String[] kr : keys) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            for (final String k : kr) {
                if (k.isEmpty()) {
                    row.addView(new View(this), new LinearLayout.LayoutParams(dp(76), dp(76)));
                    continue;
                }
                TextView kb = btn(k, v -> keyPress(k));
                kb.setTextSize(22);
                LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(dp(76), dp(76));
                kp.setMargins(dp(6), dp(6), dp(6), dp(6));
                row.addView(kb, kp);
            }
            l.addView(row);
        }
        lockBio = btn("👆", v -> promptBio());
        lockBio.setTextSize(24);
        lockBio.setVisibility(View.GONE);
        LinearLayout.LayoutParams lbp = new LinearLayout.LayoutParams(dp(76), dp(56));
        lbp.topMargin = dp(8);
        l.addView(lockBio, lbp);
        lockView.addView(l, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(lockView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void showLock() {
        pinBuf.setLength(0);
        updateDots();
        lockMsg.setText(t("PIN দিন", "Enter PIN"));
        lockView.setVisibility(View.VISIBLE);
        lockView.bringToFront();
        boolean bio = prefs.getBoolean("bio", false) && bioAvailable();
        lockBio.setVisibility(bio ? View.VISIBLE : View.GONE);
        if (bio) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    promptBio();
                }
            }, 350);
        }
    }

    private void updateDots() {
        int len = prefs.getInt("pinLen", 4);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) sb.append(i < pinBuf.length() ? "● " : "○ ");
        lockDots.setText(sb.toString().trim());
    }

    private void keyPress(String k) {
        if (System.currentTimeMillis() < lockUntil) {
            lockMsg.setText(t("একটু অপেক্ষা করুন...", "Please wait..."));
            return;
        }
        int len = prefs.getInt("pinLen", 4);
        if (k.equals("⌫")) {
            if (pinBuf.length() > 0) pinBuf.setLength(pinBuf.length() - 1);
        } else if (pinBuf.length() < len) {
            pinBuf.append(k);
        }
        updateDots();
        if (pinBuf.length() == len) {
            String h = prefs.getString("pinHash", "");
            if (hashPin(pinBuf.toString()).equals(h)) {
                wrongCount = 0;
                lockView.setVisibility(View.GONE);
            } else {
                wrongCount++;
                pinBuf.setLength(0);
                updateDots();
                if (wrongCount >= 3) {
                    wrongCount = 0;
                    lockUntil = System.currentTimeMillis() + 30000;
                    lockMsg.setText(t("৩ বার ভুল — ৩০ সেকেন্ড অপেক্ষা", "3 wrong tries - wait 30s"));
                } else {
                    lockMsg.setText(t("ভুল PIN", "Wrong PIN"));
                }
            }
        }
    }

    // ------------------------------------------------------------------ permissions + audio

    private boolean hasPerm(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void handlePermission(PermissionRequest req) {
        String origin = req.getOrigin() == null ? "" : req.getOrigin().toString();
        if (!origin.startsWith("file:") && !hostAllowed(origin)) {
            req.deny();
            return;
        }
        List<String> need = new ArrayList<String>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !hasPerm(Manifest.permission.RECORD_AUDIO)) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !hasPerm(Manifest.permission.CAMERA)) {
                need.add(Manifest.permission.CAMERA);
            }
        }
        if (need.isEmpty()) {
            grant(req, origin);
        } else {
            pendingRequest = req;
            requestPermissions(need.toArray(new String[0]), REQ_PERM);
        }
    }

    private void grant(PermissionRequest req, String origin) {
        boolean audio = false;
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) audio = true;
        }
        try {
            req.grant(req.getResources());
        } catch (Exception ignored) {
        }
        // only real web calls count as a call (not the mixer/mic panels)
        if (audio && !origin.startsWith("file:")) callStarted();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_PERM && pendingRequest != null) {
            PermissionRequest r = pendingRequest;
            pendingRequest = null;
            boolean any = false;
            for (int g : results) if (g == PackageManager.PERMISSION_GRANTED) any = true;
            if (any) {
                String o = r.getOrigin() == null ? "" : r.getOrigin().toString();
                grant(r, o);
            } else {
                r.deny();
            }
        }
    }

    private void startCallAudio() {
        try {
            am();
            if (Build.VERSION.SDK_INT >= 26) {
                if (focusRequest == null) {
                    focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                    .build())
                            .setOnAudioFocusChangeListener(focusListener)
                            .setWillPauseWhenDucked(false)
                            .build();
                }
                audioManager.requestAudioFocus(focusRequest);
            } else {
                audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_VOICE_CALL,
                        AudioManager.AUDIOFOCUS_GAIN);
            }
        } catch (Exception ignored) {
        }
    }

    private void resumeCallAudio() {
        runInMain("window.__ssResume&&window.__ssResume();");
    }

    // ------------------------------------------------------------------ media library

    private String kindOf(String name) {
        String n = name.toLowerCase();
        String[] vid = {".mp4", ".mkv", ".mov", ".3gp", ".webm"};
        for (String v : vid) if (n.endsWith(v)) return "video";
        return "audio";
    }

    private JSONArray libJson() {
        JSONArray a = new JSONArray();
        File[] fs = mixDir.listFiles();
        if (fs == null) return a;
        Arrays.sort(fs, new Comparator<File>() {
            @Override
            public int compare(File x, File y) {
                return Long.compare(x.lastModified(), y.lastModified());
            }
        });
        for (File f : fs) {
            String n = f.getName();
            int i = n.indexOf("__");
            if (i <= 0) continue;
            try {
                JSONObject o = new JSONObject();
                o.put("id", n.substring(0, i));
                o.put("name", n.substring(i + 2));
                o.put("kind", kindOf(n));
                a.put(o);
            } catch (Exception ignored) {
            }
        }
        return a;
    }

    private File findMedia(String id) {
        if (id == null || !id.matches("[a-z0-9]+")) return null;
        File[] fs = mixDir.listFiles();
        if (fs == null) return null;
        for (File f : fs) if (f.getName().startsWith(id + "__")) return f;
        return null;
    }

    private String mediaInfo(String id) {
        File f = findMedia(id);
        return "{\"size\":" + (f == null ? 0 : f.length()) + "}";
    }

    private String mediaChunk(String id, int idx) {
        File f = findMedia(id);
        if (f == null) return "";
        try {
            RandomAccessFile r = new RandomAccessFile(f, "r");
            long off = (long) idx * CHUNK;
            if (off >= r.length()) {
                r.close();
                return "";
            }
            int len = (int) Math.min((long) CHUNK, r.length() - off);
            byte[] buf = new byte[len];
            r.seek(off);
            r.readFully(buf);
            r.close();
            return Base64.encodeToString(buf, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private void notifyLibChanged() {
        final String items = libJson().toString();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript("window.__ssMixer&&window.__ssMixer.cmd({t:'lib',items:" + items + "})", null);
                }
                if (micPanel != null) {
                    micPanel.evaluateJavascript("window.onLibChanged&&window.onLibChanged()", null);
                }
                if (mixerPanel != null) {
                    mixerPanel.evaluateJavascript("window.onLibChanged&&window.onLibChanged()", null);
                }
            }
        });
    }

    private void importMedia(final Uri u) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = "file";
                long size = -1;
                Cursor c = null;
                try {
                    c = getContentResolver().query(u, null, null, null, null);
                    if (c != null && c.moveToFirst()) {
                        int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        int si = c.getColumnIndex(OpenableColumns.SIZE);
                        if (ni >= 0) name = c.getString(ni);
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                    }
                } catch (Exception ignored) {
                } finally {
                    if (c != null) c.close();
                }
                if (size > MAX_MEDIA_BYTES) {
                    toast(name + " - file is too big (max 40 MB)");
                    return;
                }
                name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                String id = Long.toString(Math.abs(System.nanoTime()), 36)
                        + Integer.toString(new Random().nextInt(1296), 36);
                File out = new File(mixDir, id + "__" + name);
                try {
                    InputStream in = getContentResolver().openInputStream(u);
                    OutputStream os = new FileOutputStream(out);
                    byte[] buf = new byte[65536];
                    long total = 0;
                    int n;
                    boolean tooBig = false;
                    while (in != null && (n = in.read(buf)) > 0) {
                        total += n;
                        if (total > MAX_MEDIA_BYTES) {
                            tooBig = true;
                            break;
                        }
                        os.write(buf, 0, n);
                    }
                    os.close();
                    if (in != null) in.close();
                    if (tooBig) {
                        out.delete();
                        toast(name + " - file is too big (max 40 MB)");
                        return;
                    }
                } catch (Exception e) {
                    out.delete();
                    toast("Import failed");
                    return;
                }
                notifyLibChanged();
            }
        }).start();
    }

    private void pickMediaFiles() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "audio/*", "video/*", "application/zip",
                "application/x-zip-compressed", "application/octet-stream"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(i, "Audio / Video / ZIP"), REQ_MEDIA);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (pendingFile != null) {
                Uri[] r = null;
                if (res == Activity.RESULT_OK && data != null) {
                    r = WebChromeClient.FileChooserParams.parseResult(res, data);
                }
                pendingFile.onReceiveValue(r);
                pendingFile = null;
            }
        } else if (req == REQ_EXPORT && res == Activity.RESULT_OK && data != null && data.getData() != null) {
            doExport(data.getData());
        } else if (req == REQ_IMPORT && res == Activity.RESULT_OK && data != null && data.getData() != null) {
            doImport(data.getData());
        } else if (req == REQ_MEDIA && res == Activity.RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    importMedia(data.getClipData().getItemAt(i).getUri());
                }
            } else if (data.getData() != null) {
                importMedia(data.getData());
            }
        }
    }

    // ================================================================== v3 additions

    private static final int DLG_TXT = 0xFFCFD8DC;

    // ---- small UI helpers

    private ImageView badgeView() {
        ImageView iv = new ImageView(this);
        iv.setImageResource(R.drawable.badge_big);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setOval(0, 0, view.getWidth(), view.getHeight());
            }
        });
        iv.setClipToOutline(true);
        return iv;
    }

    private TextView iconBtn(String icon, final String name, View.OnClickListener l) {
        TextView tv = btn(icon, l);
        tv.setTextSize(22);
        tv.setContentDescription(name);
        tv.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                toast(name);
                return true;
            }
        });
        return tv;
    }

    private LinearLayout vbox() {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setPadding(dp(18), dp(8), dp(18), dp(4));
        return b;
    }

    private interface IntCb {
        void on(int v);
    }

    private View sliderRow(final String caption, final int min, int max, int value, final IntCb cb) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(6), 0, dp(2));
        final TextView head = label(caption + ": " + value, 13, DLG_TXT, false);
        r.addView(head);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, value - min)));
        sb.setProgressTintList(ColorStateList.valueOf(cAccent));
        sb.setThumbTintList(ColorStateList.valueOf(cAccent));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int v = p + min;
                head.setText(caption + ": " + v);
                if (fromUser) cb.on(v);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        r.addView(sb);
        return r;
    }

    private void putJ(JSONObject o, String k, Object v) {
        try {
            o.put(k, v);
        } catch (Exception ignored) {
        }
    }

    private void toggleRow(String title, final String key, final boolean def, final Runnable after) {
        settingRow(title, onOff(prefs.getBoolean(key, def)), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.edit().putBoolean(key, !prefs.getBoolean(key, def)).apply();
                if (after != null) after.run();
                buildSettings();
            }
        });
    }

    private void choiceRow(final String title, final String key, final String[] labels,
                           final int[] values, int def) {
        int cur = prefs.getInt(key, def);
        String curLabel = String.valueOf(cur);
        for (int i = 0; i < values.length; i++) if (values[i] == cur) curLabel = labels[i];
        settingRow(title, curLabel, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this).setTitle(title)
                        .setItems(labels, (d, w) -> {
                            prefs.edit().putInt(key, values[w]).apply();
                            buildSettings();
                        }).show();
            }
        });
    }

    private void toggleLang() {
        prefs.edit().putBoolean("bn", !bn).apply();
        saveTabs();
        recreate();
    }

    private void confirmExit() {
        new AlertDialog.Builder(this)
                .setTitle(APP_TITLE)
                .setMessage(t("অ্যাপ থেকে বের হতে চান?", "Exit the app?"))
                .setPositiveButton(t("হ্যাঁ", "Yes"), (d, w) -> finish())
                .setNegativeButton(t("না", "No"), null)
                .show();
    }

    // ---- mic/EQ config (always a complete config, so the page bridge accepts it)

    private static final String DEFAULT_CFG = "{\"enabled\":true,\"gainDb\":84,\"thresholdDb\":-60,"
            + "\"knee\":40,\"ratio\":20,\"attack\":0.0001,\"release\":0.03,\"lowShelfDb\":14,"
            + "\"presenceDb\":20,\"highShelfDb\":16,\"limiterDb\":-0.1,\"drive\":1.8,\"loudness\":20,"
            + "\"maxBoost\":5000,\"sustain\":true,\"sustainTargetDb\":-2,\"sustainMaxGain\":64,"
            + "\"forceRawMic\":true,\"punch\":6,\"listenGain\":6,\"listenClarity\":6,"
            + "\"listenBass\":4,\"listenPunch\":5,\"micBoost\":4}";

    private JSONObject cfgObj() {
        try {
            JSONObject base = new JSONObject(DEFAULT_CFG);
            JSONObject st = new JSONObject(storeJson());
            JSONObject cfg = st.optJSONObject("micMaximizerConfig");
            if (cfg != null) {
                Iterator<String> it = cfg.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    base.put(k, cfg.get(k));
                }
            }
            return base;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private void saveCfg(JSONObject cfg) {
        try {
            JSONObject st = new JSONObject(storeJson());
            st.put("micMaximizerConfig", cfg);
            prefs.edit().putString("store", st.toString()).apply();
            pushCfg();
        } catch (Exception ignored) {
        }
    }

    private void pushCfg() {
        for (Tab tb : tabs) {
            tb.web.evaluateJavascript("window.__ssPush&&window.__ssPush();", null);
        }
    }

    private void applyPreset(int i, boolean notify) {
        presetIdx = i;
        JSONObject cfg = cfgObj();
        putJ(cfg, "listenGain", PRESET_GAINS[i]);
        saveCfg(cfg);
        if (notify) toast(PRESET_ICONS[i] + " " + PRESET_NAMES[i] + " (×" + PRESET_GAINS[i] + ")");
    }

    void nextPreset() {
        applyPreset((presetIdx + 1) % 4, true);
    }

    private void showEq() {
        final JSONObject cfg = cfgObj();
        LinearLayout box = vbox();
        box.addView(sliderRow("🥁 Bass", -30, 30, (int) Math.round(cfg.optDouble("lowShelfDb", 14)),
                v -> {
                    putJ(cfg, "lowShelfDb", v);
                    saveCfg(cfg);
                }));
        box.addView(sliderRow("🗣 Voice", -30, 30, (int) Math.round(cfg.optDouble("presenceDb", 20)),
                v -> {
                    putJ(cfg, "presenceDb", v);
                    saveCfg(cfg);
                }));
        box.addView(sliderRow("✨ Treble", -30, 30, (int) Math.round(cfg.optDouble("highShelfDb", 16)),
                v -> {
                    putJ(cfg, "highShelfDb", v);
                    saveCfg(cfg);
                }));
        new AlertDialog.Builder(this).setTitle("🎚").setView(box)
                .setPositiveButton("OK", null)
                .setNeutralButton("↺", (d, w) -> {
                    putJ(cfg, "lowShelfDb", 14);
                    putJ(cfg, "presenceDb", 20);
                    putJ(cfg, "highShelfDb", 16);
                    saveCfg(cfg);
                }).show();
    }

    private void applyCleanMode() {
        JSONObject c = cfgObj();
        putJ(c, "gainDb", 24);
        putJ(c, "loudness", 4);
        putJ(c, "maxBoost", 2000);
        putJ(c, "drive", 0.28);
        putJ(c, "thresholdDb", -38);
        putJ(c, "ratio", 12);
        putJ(c, "limiterDb", -2);
        putJ(c, "presenceDb", 8);
        putJ(c, "lowShelfDb", 4);
        putJ(c, "highShelfDb", 6);
        putJ(c, "sustain", true);
        putJ(c, "sustainTargetDb", -8);
        putJ(c, "sustainMaxGain", 12);
        putJ(c, "punch", 1);
        saveCfg(c);
        toast("🧼 Clean mode ✓");
    }

    private void showLimiter() {
        final JSONObject cfg = cfgObj();
        LinearLayout box = vbox();
        box.addView(sliderRow("📉 Limiter (dB)", -24, 0, (int) Math.round(cfg.optDouble("limiterDb", -0.1)),
                v -> {
                    putJ(cfg, "limiterDb", v);
                    saveCfg(cfg);
                }));
        box.addView(sliderRow("🔇 Threshold (dB)", -100, 0, (int) Math.round(cfg.optDouble("thresholdDb", -60)),
                v -> {
                    putJ(cfg, "thresholdDb", v);
                    saveCfg(cfg);
                }));
        box.addView(sliderRow("📈 Quiet boost max", 1, 64, (int) Math.round(cfg.optDouble("sustainMaxGain", 64)),
                v -> {
                    putJ(cfg, "sustainMaxGain", v);
                    saveCfg(cfg);
                }));
        CheckBox cb = new CheckBox(this);
        cb.setText("🔁 Sustain");
        cb.setTextColor(DLG_TXT);
        cb.setChecked(cfg.optBoolean("sustain", true));
        cb.setOnCheckedChangeListener((b, on) -> {
            putJ(cfg, "sustain", on);
            saveCfg(cfg);
        });
        box.addView(cb);
        new AlertDialog.Builder(this).setTitle("📉").setView(box)
                .setPositiveButton("OK", null)
                .setNeutralButton("🧼", (d, w) -> applyCleanMode())
                .setNegativeButton("🚀", (d, w) -> {
                    try {
                        saveCfg(new JSONObject(DEFAULT_CFG));
                        toast("🚀 Loud default ✓");
                    } catch (Exception ignored) {
                    }
                }).show();
    }

    // ---- audio route (speaker / earpiece / bluetooth / wired)

    private String routeName() {
        String[] n = {"Auto", "Speaker", "Earpiece", "Bluetooth", "Wired"};
        int r = prefs.getInt("route", 0);
        return n[r < 0 || r >= n.length ? 0 : r];
    }

    private void showRoute() {
        final String[] items = {"🔄 Auto", "🔊 Speaker", "📱 Earpiece", "🎧 Bluetooth", "🎧 Wired"};
        new AlertDialog.Builder(this).setTitle("🎧")
                .setItems(items, (d, which) -> {
                    if (which == 3 && Build.VERSION.SDK_INT >= 31
                            && !hasPerm(Manifest.permission.BLUETOOTH_CONNECT)) {
                        requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
                        toast(t("অনুমতি দিয়ে আবার বাছুন", "Allow it, then pick again"));
                        return;
                    }
                    prefs.edit().putInt("route", which).apply();
                    applyRoute(which, true);
                    buildSettings();
                }).show();
    }

    private void applyRoute(int r, boolean notify) {
        AudioManager a = am();
        boolean ok = true;
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (r == 0) {
                    a.clearCommunicationDevice();
                } else {
                    int[] types;
                    if (r == 1) types = new int[]{AudioDeviceInfo.TYPE_BUILTIN_SPEAKER};
                    else if (r == 2) types = new int[]{AudioDeviceInfo.TYPE_BUILTIN_EARPIECE};
                    else if (r == 3) types = new int[]{AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                            AudioDeviceInfo.TYPE_BLE_HEADSET};
                    else types = new int[]{AudioDeviceInfo.TYPE_WIRED_HEADSET,
                                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_USB_HEADSET};
                    AudioDeviceInfo found = null;
                    for (AudioDeviceInfo d : a.getAvailableCommunicationDevices()) {
                        for (int ty : types) if (d.getType() == ty) found = d;
                    }
                    ok = found != null && a.setCommunicationDevice(found);
                }
            } else {
                if (r == 3) {
                    a.setSpeakerphoneOn(false);
                    a.startBluetoothSco();
                    a.setBluetoothScoOn(true);
                } else {
                    a.stopBluetoothSco();
                    a.setBluetoothScoOn(false);
                    a.setSpeakerphoneOn(r == 1);
                }
            }
        } catch (Exception e) {
            ok = false;
        }
        if (notify) toast(ok ? "🎧 " + routeName() + " ✓" : t("এই ডিভাইস পাওয়া যায়নি", "That device is not available"));
    }

    // ---- mic test (hear your own voice before a call)

    private volatile boolean micTesting = false;
    private volatile int micLevel = 0;
    private volatile float micTestGain = 2f;

    private boolean hasHeadphones() {
        try {
            for (AudioDeviceInfo d : am().getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int ty = d.getType();
                if (ty == AudioDeviceInfo.TYPE_WIRED_HEADSET || ty == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                        || ty == AudioDeviceInfo.TYPE_USB_HEADSET || ty == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                        || ty == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) return true;
                if (Build.VERSION.SDK_INT >= 31 && ty == AudioDeviceInfo.TYPE_BLE_HEADSET) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void showMicTest() {
        if (sCallActive) {
            toast(t("কল চলছে — এখন মাইক টেস্ট হবে না", "A call is running"));
            return;
        }
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_PERM + 1);
            return;
        }
        LinearLayout box = vbox();
        box.addView(label("🎧 " + t("ইয়ারফোন লাগান, নইলে আওয়াজ ফিরে এসে চিৎকার করবে",
                "Use earphones or it will squeal"), 12, DLG_TXT, false));
        final ProgressBar meter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        meter.setMax(100);
        meter.setProgressTintList(ColorStateList.valueOf(cAccent));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(10));
        mp.topMargin = dp(12);
        mp.bottomMargin = dp(6);
        box.addView(meter, mp);
        box.addView(sliderRow("🔊 Gain ×", 1, 10, (int) micTestGain, v -> micTestGain = v));
        box.addView(sliderRow("⏱ Delay", 1, 4, prefs.getInt("micDelay", 1),
                v -> prefs.edit().putInt("micDelay", v).apply()));
        final TextView[] tg = new TextView[1];
        tg[0] = iconBtn("▶", "Start / Stop", v -> {
            if (micTesting) {
                stopMicTest();
                tg[0].setText("▶");
            } else {
                if (prefs.getBoolean("micNeedPhones", true) && !hasHeadphones()) {
                    toast(t("আগে ইয়ারফোন লাগান", "Plug in earphones first"));
                    return;
                }
                startMicTest();
                tg[0].setText("⏹");
            }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(10);
        box.addView(tg[0], bp);

        final Runnable[] tk = new Runnable[1];
        tk[0] = () -> {
            meter.setProgress(micLevel);
            handler.postDelayed(tk[0], 80);
        };
        handler.post(tk[0]);
        new AlertDialog.Builder(this).setTitle("🎙").setView(box)
                .setPositiveButton("OK", null)
                .setOnDismissListener(d -> {
                    stopMicTest();
                    handler.removeCallbacks(tk[0]);
                }).show();
    }

    private void startMicTest() {
        if (micTesting) return;
        micTesting = true;
        final int mul = Math.max(1, Math.min(4, prefs.getInt("micDelay", 1)));
        new Thread(new Runnable() {
            @Override
            public void run() {
                AudioRecord rec = null;
                AudioTrack trk = null;
                try {
                    int rate = 16000;
                    int minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO,
                            AudioFormat.ENCODING_PCM_16BIT);
                    int minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO,
                            AudioFormat.ENCODING_PCM_16BIT);
                    rec = new AudioRecord(MediaRecorder.AudioSource.MIC, rate,
                            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minIn * mul);
                    if (rec.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException();
                    trk = new AudioTrack.Builder()
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                            .setAudioFormat(new AudioFormat.Builder()
                                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                    .setSampleRate(rate)
                                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                            .setBufferSizeInBytes(minOut * mul)
                            .setTransferMode(AudioTrack.MODE_STREAM).build();
                    rec.startRecording();
                    trk.play();
                    short[] buf = new short[Math.max(256, minIn / 2)];
                    while (micTesting) {
                        int n = rec.read(buf, 0, buf.length);
                        if (n <= 0) continue;
                        float g = micTestGain;
                        int peak = 0;
                        for (int i = 0; i < n; i++) {
                            int s = (int) (buf[i] * g);
                            if (s > 32767) s = 32767;
                            if (s < -32768) s = -32768;
                            buf[i] = (short) s;
                            int ab = Math.abs(s);
                            if (ab > peak) peak = ab;
                        }
                        micLevel = Math.min(100, peak * 100 / 32767);
                        trk.write(buf, 0, n);
                    }
                } catch (Exception e) {
                    toast("Mic test failed");
                } finally {
                    try {
                        if (rec != null) {
                            rec.stop();
                            rec.release();
                        }
                    } catch (Exception ignored) {
                    }
                    try {
                        if (trk != null) {
                            trk.stop();
                            trk.release();
                        }
                    } catch (Exception ignored) {
                    }
                    micLevel = 0;
                    micTesting = false;
                }
            }
        }).start();
    }

    private void stopMicTest() {
        micTesting = false;
    }

    // ---- per-site presets

    private void showSitePresets() {
        final String[] labels = new String[SITE_NAMES.length];
        for (int i = 0; i < labels.length; i++) {
            int p = prefs.getInt("sp_" + ALLOWED_HOSTS[i], -1);
            labels[i] = SITE_ICONS[i] + " " + SITE_NAMES[i] + "  →  "
                    + (p < 0 || p > 3 ? "Off" : PRESET_ICONS[p] + " " + PRESET_NAMES[p]);
        }
        new AlertDialog.Builder(this).setTitle("🎛 → 🌐")
                .setItems(labels, (d, which) -> pickSitePreset(which)).show();
    }

    private void pickSitePreset(final int site) {
        String[] opts = {"Off", PRESET_ICONS[0] + " " + PRESET_NAMES[0], PRESET_ICONS[1] + " " + PRESET_NAMES[1],
                PRESET_ICONS[2] + " " + PRESET_NAMES[2], PRESET_ICONS[3] + " " + PRESET_NAMES[3]};
        new AlertDialog.Builder(this).setTitle(SITE_ICONS[site] + " " + SITE_NAMES[site])
                .setItems(opts, (d, w) -> {
                    prefs.edit().putInt("sp_" + ALLOWED_HOSTS[site], w - 1).apply();
                    lastSiteHost = "";
                    showSitePresets();
                }).show();
    }

    private void applySitePreset(String url) {
        if (url == null) return;
        String host;
        try {
            host = Uri.parse(url).getHost();
        } catch (Exception e) {
            return;
        }
        if (host == null) return;
        for (String h : ALLOWED_HOSTS) {
            if (host.equals(h) || host.endsWith("." + h)) {
                if (h.equals(lastSiteHost)) return;
                lastSiteHost = h;
                int p = prefs.getInt("sp_" + h, -1);
                if (p >= 0 && p < 4) applyPreset(p, false);
                return;
            }
        }
    }

    // ---- side drawer (the ☰ button)

    private void iconGrid(LinearLayout parent, String[] icons, String[] names, Runnable[] acts) {
        LinearLayout row = null;
        for (int i = 0; i < icons.length; i++) {
            if (i % 4 == 0) {
                row = new LinearLayout(this);
                parent.addView(row);
            }
            final Runnable a = acts[i];
            row.addView(iconBtn(icons[i], names[i], v -> {
                closeDrawer();
                a.run();
            }), lpW(1f, 3));
        }
        if (row != null) {
            int rest = (4 - icons.length % 4) % 4;
            for (int i = 0; i < rest; i++) row.addView(new View(this), lpW(1f, 3));
        }
    }

    private void buildDrawer() {
        drawerLayer = new FrameLayout(this);
        drawerLayer.setVisibility(View.GONE);
        drawerScrim = new View(this);
        drawerScrim.setBackgroundColor(0xAA000000);
        drawerScrim.setOnClickListener(v -> closeDrawer());
        drawerLayer.addView(drawerScrim, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        int sw = getResources().getDisplayMetrics().widthPixels;
        drawerW = Math.max(dp(270), Math.min(dp(340), (int) (sw * 0.82f)));
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(cBar);
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(12), dp(24), dp(12), dp(24));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setGravity(Gravity.CENTER_HORIZONTAL);
        head.addView(badgeView(), new LinearLayout.LayoutParams(dp(96), dp(96)));
        TextView n = label(APP_TITLE, 18, cAccent, true);
        n.setPadding(0, dp(8), 0, 0);
        head.addView(n);
        head.addView(label(APP_SUB, 12, cDim, false));
        drawerTimer = label("⏱ --:--", 13, cText, true);
        drawerTimer.setPadding(0, dp(6), 0, dp(4));
        head.addView(drawerTimer);
        p.addView(head, lpFull(0));

        p.addView(section("🎛"));
        iconGrid(p, PRESET_ICONS, PRESET_NAMES, new Runnable[]{
                () -> applyPreset(0, true), () -> applyPreset(1, true),
                () -> applyPreset(2, true), () -> applyPreset(3, true)});

        p.addView(section("🎧"));
        iconGrid(p, new String[]{"🎙", "🎚", "📉", "🎧"},
                new String[]{t("মাইক টেস্ট", "Mic test"), t("ইকুয়ালাইজার", "Equalizer"),
                        "Limiter / Noise", t("অডিও আউটপুট", "Audio output")},
                new Runnable[]{() -> showMicTest(), () -> showEq(), () -> showLimiter(), () -> showRoute()});

        p.addView(section("📞"));
        iconGrid(p, new String[]{"🎵", "📋", "🔋", "🖼"},
                new String[]{t("মিক্সার", "Mixer"), t("কল লগ", "Call log"),
                        t("ব্যাটারি ছাড়", "Battery exemption"), "PiP"},
                new Runnable[]{() -> showPage(2), () -> showCallLog(), () -> askBatteryExempt(),
                        () -> enterPip()});

        p.addView(section("🌐"));
        iconGrid(p, new String[]{"⭐", "🕘", "📥", "🔗"},
                new String[]{t("বুকমার্ক", "Bookmarks"), t("হিস্টরি", "History"),
                        t("ডাউনলোড", "Downloads"), t("সাইট", "Sites")},
                new Runnable[]{
                        () -> showUrlList("bookmarks", "⭐", true),
                        () -> showUrlList("history", "🕘", false),
                        () -> menuAction(100),
                        () -> showSites()});

        p.addView(section("⚡"));
        iconGrid(p, new String[]{"🎨", "🌍", "🖥", "📱"},
                new String[]{t("থিম", "Theme"), t("ভাষা", "Language"), "Desktop",
                        t("স্ক্রিন চালু", "Keep screen on")},
                new Runnable[]{() -> showThemeDialog(), () -> toggleLang(),
                        () -> toggleDesktop(), () -> {
                            boolean on = !prefs.getBoolean("keepOn", true);
                            prefs.edit().putBoolean("keepOn", on).apply();
                            applyWindowFlags();
                            toast("📱 " + onOff(on));
                        }});

        p.addView(section("🔒"));
        iconGrid(p, new String[]{"💾", "♻", "🔐", "ℹ", "⚙", "🚪"},
                new String[]{t("ব্যাকআপ", "Backup"), t("রিস্টোর", "Restore"), t("অ্যাপ লক", "App lock"),
                        t("সম্পর্কে", "About"), t("সেটিং", "Settings"), t("বের হন", "Exit")},
                new Runnable[]{() -> exportSettings(), () -> importSettings(), () -> pinMenu(),
                        () -> showAbout(), () -> showPage(4), () -> confirmExit()});

        TextView hint = label(t("আইকন চেপে ধরলে নাম দেখাবে", "Long-press an icon to see its name"),
                11, cDim, false);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(14), 0, 0);
        p.addView(hint, lpFull(0));

        sv.addView(p);
        drawerPanel = sv;
        drawerLayer.addView(sv, new FrameLayout.LayoutParams(drawerW,
                ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START));
        root.addView(drawerLayer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private boolean drawerOpen() {
        return drawerLayer != null && drawerLayer.getVisibility() == View.VISIBLE;
    }

    private void openDrawer() {
        if (drawerLayer == null) return;
        drawerPanel.animate().cancel();
        drawerLayer.setVisibility(View.VISIBLE);
        drawerPanel.setTranslationX(-drawerW);
        drawerPanel.animate().translationX(0).setDuration(200).start();
        drawerScrim.setAlpha(0f);
        drawerScrim.animate().alpha(1f).setDuration(200).start();
        updateStatus();
    }

    private void closeDrawer() {
        if (!drawerOpen()) return;
        drawerPanel.animate().cancel();
        drawerScrim.animate().alpha(0f).setDuration(160).start();
        drawerPanel.animate().translationX(-drawerW).setDuration(180)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        drawerLayer.setVisibility(View.GONE);
                    }
                }).start();
    }

    // ---- themes / accent colour / about

    private void showThemeDialog() {
        String[] names = new String[THEMES.length];
        for (int i = 0; i < THEMES.length; i++) names[i] = THEMES[i][0];
        new AlertDialog.Builder(this).setTitle("🎨")
                .setItems(names, (d, w) -> {
                    if (w == CUSTOM_THEME) {
                        showAccentDialog();
                        return;
                    }
                    prefs.edit().putInt("theme", w).apply();
                    saveTabs();
                    recreate();
                }).show();
    }

    private void showAccentDialog() {
        final String[] cols = {"#ff3d71", "#ff5a4d", "#ff9f1c", "#ffc83d", "#a3e635", "#34d399",
                "#5ff5d6", "#4da3ff", "#7c5cff", "#c77dff", "#ff6ec7", "#ffffff"};
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout box = vbox();
        LinearLayout row = null;
        for (int i = 0; i < cols.length; i++) {
            if (i % 6 == 0) {
                row = new LinearLayout(this);
                box.addView(row);
            }
            final String col = cols[i];
            View sw = new View(this);
            sw.setBackground(round(Color.parseColor(col), 0xFF888888, 22));
            sw.setOnClickListener(v -> {
                if (dlg[0] != null) dlg[0].dismiss();
                applyAccent(col);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(40), dp(40));
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            row.addView(sw, lp);
        }
        final EditText hex = new EditText(this);
        hex.setHint("#RRGGBB");
        hex.setSingleLine(true);
        hex.setTextColor(DLG_TXT);
        box.addView(hex);
        dlg[0] = new AlertDialog.Builder(this).setTitle("🌈").setView(box)
                .setPositiveButton("OK", (d, w) -> {
                    String s = hex.getText().toString().trim();
                    if (!s.startsWith("#")) s = "#" + s;
                    applyAccent(s);
                })
                .setNegativeButton("✕", null).create();
        dlg[0].show();
    }

    private void applyAccent(String col) {
        try {
            Color.parseColor(col);
        } catch (Exception e) {
            toast(t("কালার ঠিক নেই", "Invalid colour"));
            return;
        }
        prefs.edit().putString("accentHex", col).putInt("theme", CUSTOM_THEME).apply();
        saveTabs();
        recreate();
    }

    private void showAbout() {
        LinearLayout box = vbox();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.addView(badgeView(), new LinearLayout.LayoutParams(dp(120), dp(120)));
        TextView m = label(APP_TITLE + " v3.0\n" + APP_SUB + "\nBy Mahir", 14, DLG_TXT, false);
        m.setGravity(Gravity.CENTER);
        m.setPadding(0, dp(10), 0, 0);
        box.addView(m);
        new AlertDialog.Builder(this).setView(box).setPositiveButton("OK", null).show();
    }

    // ---- picture-in-picture

    void enterPip() {
        if (Build.VERSION.SDK_INT < 26) {
            toast("PiP: Android 8+");
            return;
        }
        try {
            if (page != 3) showPage(3);
            enterPictureInPictureMode(new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(9, 16)).build());
        } catch (Exception e) {
            toast("PiP not available");
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Build.VERSION.SDK_INT >= 26 && prefs.getBoolean("pipAuto", false) && sCallActive
                && customView == null && (lockView == null || lockView.getVisibility() != View.VISIBLE)) {
            enterPip();
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean inPipNow, Configuration newConfig) {
        super.onPictureInPictureModeChanged(inPipNow, newConfig);
        inPip = inPipNow;
        int vis = inPipNow ? View.GONE : View.VISIBLE;
        if (topBar != null) topBar.setVisibility(vis);
        if (navBar != null) navBar.setVisibility(vis);
        if (webTabRow != null) webTabRow.setVisibility(vis);
        if (webAddrBar != null) webAddrBar.setVisibility(vis);
        if (fcall != null) fcall.setVisibility(inPipNow ? View.GONE : (sCallActive ? View.VISIBLE : View.GONE));
        if (inPipNow) {
            closeDrawer();
            progress.setVisibility(View.GONE);
        }
    }

    // ---- notification controls / background stability

    void refreshNotif() {
        if (!sCallActive) return;
        try {
            Intent si = new Intent(this, CallService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(si);
            else startService(si);
        } catch (Exception ignored) {
        }
    }

    private String maskLabel() {
        int m = prefs.getInt("notifMask", 7);
        StringBuilder sb = new StringBuilder();
        if ((m & 1) != 0) sb.append("🎤 ");
        if ((m & 2) != 0) sb.append("🎛 ");
        if ((m & 4) != 0) sb.append("⏹");
        return sb.length() == 0 ? "—" : sb.toString().trim();
    }

    private void showNotifButtons() {
        final int[] mask = {prefs.getInt("notifMask", 7)};
        final String[] items = {"🎤 Mute", "🎛 Preset", "⏹ End"};
        boolean[] on = {(mask[0] & 1) != 0, (mask[0] & 2) != 0, (mask[0] & 4) != 0};
        new AlertDialog.Builder(this).setTitle("🔔")
                .setMultiChoiceItems(items, on, (d, which, checked) -> {
                    if (checked) mask[0] |= (1 << which);
                    else mask[0] &= ~(1 << which);
                })
                .setPositiveButton("OK", (d, w) -> {
                    prefs.edit().putInt("notifMask", mask[0]).apply();
                    refreshNotif();
                    buildSettings();
                })
                .setNegativeButton("✕", null).show();
    }

    private void askBatteryExempt() {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    toast("🔋 ✓ " + t("আগেই ছাড় দেওয়া আছে", "Already exempt"));
                    return;
                }
            }
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
                toast("Cannot open");
            }
        }
    }

    // ---- call log

    private String currentHost() {
        try {
            String u = web == null ? null : web.getUrl();
            if (u != null) {
                String h = Uri.parse(u).getHost();
                if (h != null) return h.startsWith("www.") ? h.substring(4) : h;
            }
        } catch (Exception ignored) {
        }
        return "?";
    }

    private void logCallStart() {
        if (!prefs.getBoolean("logOn", true)) return;
        try {
            JSONArray a = loadList("calllog");
            JSONObject o = new JSONObject();
            o.put("t", System.currentTimeMillis());
            o.put("s", currentHost());
            o.put("d", 0);
            a.put(o);
            JSONArray out = new JSONArray();
            for (int i = Math.max(0, a.length() - 100); i < a.length(); i++) out.put(a.get(i));
            prefs.edit().putString("calllog", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void logCallEnd() {
        if (!prefs.getBoolean("logOn", true) || !sCallActive) return;
        try {
            JSONArray a = loadList("calllog");
            if (a.length() == 0) return;
            JSONObject o = a.getJSONObject(a.length() - 1);
            if (o.optLong("d", 0) == 0) {
                o.put("d", System.currentTimeMillis() - sCallStart);
                prefs.edit().putString("calllog", a.toString()).apply();
            }
        } catch (Exception ignored) {
        }
    }

    private void pruneCallLog() {
        int days = prefs.getInt("logDays", 0);
        if (days <= 0) return;
        try {
            JSONArray a = loadList("calllog");
            JSONArray out = new JSONArray();
            long cut = System.currentTimeMillis() - days * 86400000L;
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (o.optLong("t") >= cut) out.put(o);
            }
            prefs.edit().putString("calllog", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void showCallLog() {
        JSONArray a = loadList("calllog");
        int n = a.length();
        if (n == 0) {
            toast(t("খালি", "Empty"));
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault());
        String[] items = new String[n];
        long total = 0;
        for (int i = 0; i < n; i++) {
            JSONObject o = a.optJSONObject(n - 1 - i);
            if (o == null) {
                items[i] = "";
                continue;
            }
            long d = o.optLong("d", 0);
            total += d;
            items[i] = "📞 " + o.optString("s") + "\n" + f.format(new Date(o.optLong("t")))
                    + "  •  " + (d > 0 ? fmt(d) : "--:--");
        }
        new AlertDialog.Builder(this).setTitle("📋  ⏱ " + fmt(total))
                .setItems(items, null)
                .setPositiveButton("OK", null)
                .setNegativeButton("🗑", (d, w) -> prefs.edit().putString("calllog", "[]").apply())
                .show();
    }

    // ---- fingerprint

    private boolean bioAvailable() {
        if (Build.VERSION.SDK_INT < 29) return false;
        try {
            BiometricManager bm = (BiometricManager) getSystemService(BIOMETRIC_SERVICE);
            return bm != null && bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
        } catch (Exception e) {
            return false;
        }
    }

    private void promptBio() {
        if (Build.VERSION.SDK_INT < 29 || !prefs.getBoolean("bio", false) || !bioAvailable()) return;
        try {
            BiometricPrompt bp = new BiometricPrompt.Builder(this)
                    .setTitle(APP_TITLE)
                    .setNegativeButton("PIN", getMainExecutor(), (d, w) -> {
                    })
                    .build();
            bp.authenticate(new CancellationSignal(), getMainExecutor(),
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                            wrongCount = 0;
                            lockView.setVisibility(View.GONE);
                        }
                    });
        } catch (Exception ignored) {
        }
    }

    private void toggleBio() {
        if (prefs.getBoolean("bio", false)) {
            prefs.edit().putBoolean("bio", false).apply();
            buildSettings();
            return;
        }
        if (prefs.getString("pinHash", null) == null) {
            toast(t("আগে PIN সেট করুন", "Set a PIN first"));
            return;
        }
        if (!bioAvailable()) {
            toast(t("ফিঙ্গারপ্রিন্ট পাওয়া যায়নি (Android 10+ ও ফিঙ্গারপ্রিন্ট সেট করা লাগবে)",
                    "Fingerprint unavailable (needs Android 10+ with a fingerprint enrolled)"));
            return;
        }
        prefs.edit().putBoolean("bio", true).apply();
        buildSettings();
    }

    // ---- downloads from blob: / data: links

    private String extFor(String mime) {
        if (mime == null) return "";
        String e = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime.split(";")[0].trim());
        return e == null ? "" : e;
    }

    private void blobDownload(WebView w, String url, String mime) {
        blobToken = Long.toString(Math.abs(new Random().nextLong()), 36);
        blobFirst = true;
        String ext = extFor(mime);
        String name = "download_" + System.currentTimeMillis() + (ext.isEmpty() ? "" : "." + ext);
        String safeUrl = url.replace("\\", "\\\\").replace("'", "\\'");
        String safeMime = mime == null ? "" : mime.replace("'", "").replace("\\", "");
        String js = "(function(){var T='" + blobToken + "',U='" + safeUrl + "',N='" + name + "',M='" + safeMime + "';"
                + "fetch(U).then(function(r){return r.blob();}).then(function(b){var rd=new FileReader();"
                + "rd.onloadend=function(){var s=String(rd.result||''),d=s.substring(s.indexOf(',')+1),C=262144,k=0;"
                + "if(d.length===0){SSBridge.blobChunk(T,'',true,N,b.type||M);return;}"
                + "for(;k<d.length;k+=C){SSBridge.blobChunk(T,d.substring(k,k+C),k+C>=d.length,N,b.type||M);}};"
                + "rd.readAsDataURL(b);}).catch(function(e){SSBridge.blobFail(T);});})();";
        toast("⬇ " + name);
        w.evaluateJavascript(js, null);
    }

    private synchronized void onBlobChunk(String token, String b64, boolean last, String name, String mime) {
        if (token == null || !token.equals(blobToken)) return;
        try {
            if (blobFirst) {
                blobFirst = false;
                if (blobOut != null) {
                    try {
                        blobOut.close();
                    } catch (Exception ignored) {
                    }
                }
                blobTmp = new File(getCacheDir(), "blob.tmp");
                blobOut = new FileOutputStream(blobTmp, false);
                blobTotal = 0;
            }
            if (blobOut == null) return;
            if (b64 != null && !b64.isEmpty()) {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                blobTotal += data.length;
                if (blobTotal > 200L * 1024L * 1024L) {
                    blobOut.close();
                    blobOut = null;
                    blobToken = "";
                    toast(t("ফাইল অনেক বড় (সর্বোচ্চ ২০০ MB)", "File too big (max 200 MB)"));
                    return;
                }
                blobOut.write(data);
            }
            if (last) {
                blobOut.close();
                blobOut = null;
                blobToken = "";
                String m = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                saveFileToDownloads(blobTmp, name, m);
            }
        } catch (Exception e) {
            blobToken = "";
            toast("Download failed");
        }
    }

    private void saveDataUrl(final String url) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    int c = url.indexOf(',');
                    String meta = url.substring(5, c);
                    String data = url.substring(c + 1);
                    boolean b64 = meta.endsWith(";base64");
                    String mime = meta.replace(";base64", "");
                    if (mime.isEmpty()) mime = "text/plain";
                    byte[] bytes = b64 ? Base64.decode(data, Base64.DEFAULT) : Uri.decode(data).getBytes("UTF-8");
                    File tmp = new File(getCacheDir(), "data.tmp");
                    FileOutputStream fo = new FileOutputStream(tmp);
                    fo.write(bytes);
                    fo.close();
                    String ext = extFor(mime);
                    saveFileToDownloads(tmp, "download_" + System.currentTimeMillis()
                            + (ext.isEmpty() ? "" : "." + ext), mime);
                } catch (Exception e) {
                    toast("Download failed");
                }
            }
        }).start();
    }

    private void copyStream(File src, OutputStream os) throws Exception {
        InputStream in = new FileInputStream(src);
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        in.close();
        os.close();
    }

    private void saveFileToDownloads(File src, String name, String mime) {
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) throw new Exception("insert");
                OutputStream os = getContentResolver().openOutputStream(u);
                if (os == null) throw new Exception("open");
                copyStream(src, os);
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                dir.mkdirs();
                copyStream(src, new FileOutputStream(new File(dir, name)));
            }
            toast("✓ Downloads/" + name);
        } catch (Exception e) {
            toast("Save failed");
        }
    }

    // ---- backup / restore to a file

    private static final String[] BK_SKIP = {"pinHash", "pinSalt", "pinLen", "bio", "history",
            "calllog", "tabs", "curTab", "lastUrl"};

    private boolean bkSkip(String k) {
        for (String s : BK_SKIP) if (s.equals(k)) return true;
        return false;
    }

    void exportSettings() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "mahir-backup.json");
        try {
            startActivityForResult(i, REQ_EXPORT);
        } catch (Exception e) {
            toast("Cannot open");
        }
    }

    void importSettings() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_IMPORT);
        } catch (Exception e) {
            toast("Cannot open");
        }
    }

    private void doExport(Uri u) {
        try {
            JSONObject o = new JSONObject();
            for (Map.Entry<String, ?> e : prefs.getAll().entrySet()) {
                String k = e.getKey();
                Object v = e.getValue();
                if (bkSkip(k) || v == null) continue;
                JSONObject x = new JSONObject();
                if (v instanceof String) x.put("t", "s");
                else if (v instanceof Integer) x.put("t", "i");
                else if (v instanceof Boolean) x.put("t", "b");
                else if (v instanceof Long) x.put("t", "l");
                else if (v instanceof Float) x.put("t", "f");
                else continue;
                x.put("v", v instanceof Float ? (Object) Double.valueOf(((Float) v).doubleValue()) : v);
                o.put(k, x);
            }
            OutputStream os = getContentResolver().openOutputStream(u);
            if (os == null) throw new Exception("open");
            os.write(o.toString(2).getBytes("UTF-8"));
            os.close();
            toast("💾 ✓");
        } catch (Exception e) {
            toast("Backup failed");
        }
    }

    private void doImport(Uri u) {
        try {
            InputStream in = getContentResolver().openInputStream(u);
            if (in == null) throw new Exception("open");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            JSONObject o = new JSONObject(bo.toString("UTF-8"));
            SharedPreferences.Editor ed = prefs.edit();
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                if (bkSkip(k)) continue;
                JSONObject x = o.optJSONObject(k);
                if (x == null) continue;
                String ty = x.optString("t");
                if ("s".equals(ty)) ed.putString(k, x.getString("v"));
                else if ("i".equals(ty)) ed.putInt(k, x.getInt("v"));
                else if ("b".equals(ty)) ed.putBoolean(k, x.getBoolean("v"));
                else if ("l".equals(ty)) ed.putLong(k, x.getLong("v"));
                else if ("f".equals(ty)) ed.putFloat(k, (float) x.getDouble("v"));
            }
            ed.apply();
            saveTabs();
            recreate();
        } catch (Exception e) {
            toast(t("ব্যাকআপ ঠিক নেই", "Invalid backup"));
        }
    }

    private void backupSettings() {
        exportSettings();
    }

    private void restoreSettings() {
        importSettings();
    }

    // ---- settings page

    private void buildSettings() {
        settingsBox.removeAllViews();
        settingsBox.addView(label("⚙ " + t("সেটিং", "Settings"), 20, cAccent, true));

        settingsBox.addView(section("🎨"));
        settingRow("🎨 " + t("থিম", "Theme"), THEMES[themeIdx][0], v -> showThemeDialog());
        settingRow("🌈 " + t("নিজের কালার", "Accent color"),
                prefs.getString("accentHex", "#ff3d71"), v -> showAccentDialog());
        settingRow("🌍 " + t("ভাষা", "Language"), bn ? "বাংলা" : "English", v -> toggleLang());
        settingRow("🔤 " + t("লেখার সাইজ", "Text size"), prefs.getInt("zoom", 100) + "%", v -> {
            new AlertDialog.Builder(this).setTitle("🔤")
                    .setItems(new String[]{"90%", "100%", "120%", "140%"}, (d, w) -> {
                        int[] z = {90, 100, 120, 140};
                        prefs.edit().putInt("zoom", z[w]).apply();
                        for (Tab tb : tabs) tb.web.getSettings().setTextZoom(z[w]);
                        buildSettings();
                    }).show();
        });
        toggleRow("📱 " + t("স্ক্রিন চালু রাখুন", "Keep screen on"), "keepOn", true,
                new Runnable() {
                    @Override
                    public void run() {
                        applyWindowFlags();
                    }
                });

        settingsBox.addView(section("🎧"));
        int ap = prefs.getInt("autoPreset", -1);
        settingRow("🎛 " + t("কল শুরুতে প্রিসেট", "Preset on call start"),
                ap < 0 ? "Off" : PRESET_ICONS[ap] + " " + PRESET_NAMES[ap], v -> {
                    new AlertDialog.Builder(this).setTitle("🎛")
                            .setItems(new String[]{"Off", PRESET_NAMES[0], PRESET_NAMES[1],
                                    PRESET_NAMES[2], PRESET_NAMES[3]}, (d, w) -> {
                                prefs.edit().putInt("autoPreset", w - 1).apply();
                                buildSettings();
                            }).show();
                });
        settingRow("🌐🎛 " + t("সাইট অনুযায়ী প্রিসেট", "Per-site presets"), "", v -> showSitePresets());
        settingRow("🎚 " + t("ইকুয়ালাইজার", "Equalizer"), "", v -> showEq());
        settingRow("📉 Limiter / Noise", "", v -> showLimiter());
        settingRow("🎧 " + t("অডিও আউটপুট", "Audio output"), routeName(), v -> showRoute());
        settingRow("🎙 " + t("মাইক টেস্ট", "Mic test"), "", v -> showMicTest());
        toggleRow("🎧 " + t("মাইক টেস্টে ইয়ারফোন লাগবে", "Mic test needs earphones"), "micNeedPhones", true, null);
        settingRow("🖥 Desktop mode", onOff(desktop), v -> {
            toggleDesktop();
            buildSettings();
        });

        settingsBox.addView(section("🔔"));
        settingRow("🔔 " + t("নোটিফিকেশন বাটন", "Notification buttons"), maskLabel(), v -> showNotifButtons());
        toggleRow("🔓 " + t("লক স্ক্রিনে কন্ট্রোল", "Controls on lock screen"), "lockCtl", true,
                new Runnable() {
                    @Override
                    public void run() {
                        refreshNotif();
                    }
                });
        toggleRow("🖼 " + t("হোম চাপলে অটো PiP", "Auto PiP on leave"), "pipAuto", false, null);

        settingsBox.addView(section("🔋"));
        settingRow("🔋 " + t("ব্যাটারি অপ্টিমাইজেশন ছাড়", "Battery optimization"), "", v -> askBatteryExempt());
        toggleRow("⚡ " + t("কলে CPU জাগিয়ে রাখা", "Keep CPU awake in call"), "wakeLock", true, null);
        toggleRow("📶 " + t("কলে Wi-Fi লক", "Wi-Fi lock in call"), "wifiLock", true, null);

        settingsBox.addView(section("📋"));
        toggleRow("📋 " + t("কল লগ", "Call log"), "logOn", true, null);
        choiceRow("🗑 " + t("অটো ডিলিট", "Auto delete"), "logDays",
                new String[]{"Off", "7d", "30d"}, new int[]{0, 7, 30}, 0);
        settingRow("📋 " + t("লগ দেখুন", "View log"), "", v -> showCallLog());

        settingsBox.addView(section("🔒"));
        boolean hasPin = prefs.getString("pinHash", null) != null;
        settingRow("🔐 " + t("অ্যাপ লক (PIN)", "App lock (PIN)"),
                hasPin ? t("চালু ✓", "ON ✓") : "OFF", v -> pinMenu());
        settingRow("👆 " + t("ফিঙ্গারপ্রিন্ট", "Fingerprint"), onOff(prefs.getBoolean("bio", false)),
                v -> toggleBio());
        choiceRow("⏲ " + t("অটো লক", "Auto-lock after"), "lockDelay",
                new String[]{"0s", "15s", "30s", "1m", "5m"},
                new int[]{0, 15000, 30000, 60000, 300000}, 30000);
        toggleRow("🛡 " + t("স্ক্রিনশট বন্ধ", "Block screenshots"), "secure", false,
                new Runnable() {
                    @Override
                    public void run() {
                        applyWindowFlags();
                    }
                });
        toggleRow("🙈 " + t("রিসেন্টে প্রিভিউ লুকান", "Hide in recents"), "hidePreview", false,
                new Runnable() {
                    @Override
                    public void run() {
                        applyWindowFlags();
                    }
                });
        settingRow("🧹 " + t("ক্যাশ ও কুকি মুছুন", "Clear cache & cookies"), "", v -> {
            new AlertDialog.Builder(this).setTitle(t("নিশ্চিত?", "Sure?"))
                    .setMessage(t("সব ওয়েবে আবার লগইন করতে হবে।", "You will have to log in again."))
                    .setPositiveButton(t("হ্যাঁ", "Yes"), (d, w) -> {
                        for (Tab tb : tabs) tb.web.clearCache(true);
                        CookieManager.getInstance().removeAllCookies(null);
                        CookieManager.getInstance().flush();
                        WebStorage.getInstance().deleteAllData();
                        reloadPage();
                        toast("✓");
                    }).setNegativeButton(t("না", "No"), null).show();
        });

        settingsBox.addView(section("💾"));
        settingRow("💾 " + t("সেটিং ব্যাকআপ (ফাইল)", "Backup settings (file)"), "", v -> backupSettings());
        settingRow("♻ " + t("সেটিং রিস্টোর (ফাইল)", "Restore settings (file)"), "", v -> restoreSettings());

        settingsBox.addView(section("ℹ"));
        settingRow("ℹ " + t("সম্পর্কে", "About"), "v3.0", v -> showAbout());
    }


    // ------------------------------------------------------------------ JS bridges

    private String storeJson() {
        return prefs.getString("store", "{}");
    }

    /** Used by the web pages (Messenger, Facebook ...). */
    public class MainBridge {
        @JavascriptInterface
        public String getConfig() {
            try {
                JSONObject st = new JSONObject(storeJson());
                JSONObject cfg = st.optJSONObject("micMaximizerConfig");
                return cfg == null ? "{}" : cfg.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void ready() {
            lastReady = System.currentTimeMillis();
        }

        @JavascriptInterface
        public String listMedia() {
            return libJson().toString();
        }

        @JavascriptInterface
        public String mediaInfo(String id) {
            return MainActivity.this.mediaInfo(id);
        }

        @JavascriptInterface
        public String mediaChunk(String id, int idx) {
            return MainActivity.this.mediaChunk(id, idx);
        }

        @JavascriptInterface
        public void mixerState(String json) {
            if (json != null) mixerState = json;
        }

        @JavascriptInterface
        public void blobChunk(String token, String b64, boolean last, String name, String mime) {
            onBlobChunk(token, b64, last, name, mime);
        }

        @JavascriptInterface
        public void blobFail(String token) {
            if (token != null && token.equals(blobToken)) {
                blobToken = "";
                toast("Download failed");
            }
        }
    }

    /** Used by the Mic / Mixer panel pages. */
    public class PanelBridge {
        @JavascriptInterface
        public String getStore() {
            return storeJson();
        }

        @JavascriptInterface
        public void setStore(String s) {
            prefs.edit().putString("store", s == null ? "{}" : s).apply();
            runInMain("window.__ssPush&&window.__ssPush();");
        }

        @JavascriptInterface
        public String lastReady() {
            return String.valueOf(lastReady);
        }

        @JavascriptInterface
        public void mixerCmd(String json) {
            runInMain("window.__ssMixer&&window.__ssMixer.cmd(" + json + ")");
        }

        @JavascriptInterface
        public String getMixerState() {
            return mixerState;
        }

        @JavascriptInterface
        public String listMedia() {
            return libJson().toString();
        }

        @JavascriptInterface
        public String mediaInfo(String id) {
            return MainActivity.this.mediaInfo(id);
        }

        @JavascriptInterface
        public String mediaChunk(String id, int idx) {
            return MainActivity.this.mediaChunk(id, idx);
        }

        @JavascriptInterface
        public String fileUrl(String id) {
            File f = findMedia(id);
            return f == null ? "" : "file://" + f.getAbsolutePath();
        }

        @JavascriptInterface
        public void deleteMedia(String id) {
            File f = findMedia(id);
            if (f != null) f.delete();
            notifyLibChanged();
        }

        @JavascriptInterface
        public void pickFiles() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pickMediaFiles();
                }
            });
        }
    }
}

package com.mahir.dragonmaster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/** Keeps the call alive in the background (microphone foreground service). */
public class CallService extends Service {

    private static final String CHANNEL = "dm_call";

    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Notification.Action action(int iconRes, String title, String act, int code) {
        Intent i = new Intent(this, CallActionReceiver.class);
        i.setAction(act);
        PendingIntent pi = PendingIntent.getBroadcast(this, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(Icon.createWithResource(this, iconRes), title, pi).build();
    }

    private Bitmap largeIcon() {
        try {
            Bitmap src = BitmapFactory.decodeResource(getResources(), R.drawable.badge_big);
            if (src == null) return null;
            Bitmap sm = Bitmap.createScaledBitmap(src, 128, 128, true);
            if (sm != src) src.recycle();
            return sm;
        } catch (Exception e) {
            return null;
        }
    }

    private void acquireLocks(SharedPreferences p) {
        try {
            if (p.getBoolean("wakeLock", true) && wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dragonmaster:call");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(12L * 60L * 60L * 1000L);
            }
            if (p.getBoolean("wifiLock", true) && wifiLock == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                int mode = Build.VERSION.SDK_INT >= 29
                        ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                wifiLock = wm.createWifiLock(mode, "dragonmaster:wifi");
                wifiLock.setReferenceCounted(false);
                wifiLock.acquire();
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences prefs = getSharedPreferences("PREFS", Context.MODE_PRIVATE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "Call", NotificationManager.IMPORTANCE_LOW));
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        long since = MainActivity.sCallStart > 0 ? MainActivity.sCallStart : System.currentTimeMillis();
        b.setContentTitle("DRAGON MASTER")
                .setContentText(MainActivity.sMicMuted ? "Mic muted" : "Call is running")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setLargeIcon(largeIcon())
                .setContentIntent(pi)
                .setOngoing(true)
                .setShowWhen(true)
                .setWhen(since)
                .setUsesChronometer(true)
                .setVisibility(prefs.getBoolean("lockCtl", true)
                        ? Notification.VISIBILITY_PUBLIC : Notification.VISIBILITY_PRIVATE);
        int mask = prefs.getInt("notifMask", 7);
        if ((mask & 1) != 0) {
            b.addAction(action(android.R.drawable.ic_lock_silent_mode,
                    MainActivity.sMicMuted ? "Unmute" : "Mute", CallActionReceiver.A_MUTE, 1));
        }
        if ((mask & 2) != 0) {
            b.addAction(action(android.R.drawable.ic_menu_manage, "Preset", CallActionReceiver.A_PRESET, 2));
        }
        if ((mask & 4) != 0) {
            b.addAction(action(android.R.drawable.ic_menu_close_clear_cancel, "End", CallActionReceiver.A_END, 3));
        }
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(77, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        acquireLocks(prefs);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {
        }
        try {
            if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        } catch (Exception ignored) {
        }
        wakeLock = null;
        wifiLock = null;
        super.onDestroy();
    }
}
